export interface PositionSizeParams {
  accountBalance: number;
  riskPercentage: number;
  stopLossPips: number;
  pipValue: number;
  exchangeRate?: number;
}

export interface PositionSizeResult {
  lotSize: number;
  units: number;
  moneyAtRisk: number;
  pipValue: number;
}

export interface PipValueParams {
  currencyPair: string;
  lotSize: number;
  accountCurrency: string;
  exchangeRate?: number;
}

export interface ProfitLossParams {
  lotSize: number;
  openPrice: number;
  closePrice: number;
  pipValue: number;
  direction: 'buy' | 'sell';
}

export interface CompoundingParams {
  initialBalance: number;
  monthlyReturn: number;
  months: number;
  monthlyDeposit?: number;
}

export interface FibonacciParams {
  high: number;
  low: number;
  direction: 'uptrend' | 'downtrend';
}

export interface PivotPointsParams {
  high: number;
  low: number;
  close: number;
  method: 'standard' | 'demark';
}

export class CalculatorUtils {
  // Calculate position size based on risk management
  static calculatePositionSize(params: PositionSizeParams): PositionSizeResult {
    const { accountBalance, riskPercentage, stopLossPips, pipValue, exchangeRate = 1 } = params;
    
    const moneyAtRisk = (accountBalance * riskPercentage) / 100;
    const adjustedPipValue = pipValue * exchangeRate;
    const lotSize = moneyAtRisk / (stopLossPips * adjustedPipValue);
    const units = lotSize * 100000; // Standard lot is 100,000 units
    
    return {
      lotSize: Math.round(lotSize * 100) / 100, // Round to 2 decimal places
      units: Math.round(units),
      moneyAtRisk,
      pipValue: adjustedPipValue,
    };
  }

  // Calculate pip value for different currency pairs
  static calculatePipValue(params: PipValueParams): number {
    const { currencyPair, lotSize, accountCurrency, exchangeRate = 1 } = params;
    
    // Standard pip value calculation
    const [base, quote] = currencyPair.split('/');
    let pipValue = 0;

    if (quote === accountCurrency) {
      // Direct quote (e.g., EUR/USD for USD account)
      pipValue = (0.0001 * lotSize * 100000);
    } else if (base === accountCurrency) {
      // Indirect quote (e.g., USD/CAD for USD account)
      pipValue = (0.0001 * lotSize * 100000) / exchangeRate;
    } else {
      // Cross currency (e.g., GBP/JPY for USD account)
      pipValue = (0.0001 * lotSize * 100000) * exchangeRate;
    }

    // Special case for JPY pairs (pip = 0.01)
    if (quote === 'JPY') {
      pipValue = pipValue * 100;
    }

    return Math.round(pipValue * 100) / 100;
  }

  // Calculate profit/loss
  static calculateProfitLoss(params: ProfitLossParams): number {
    const { lotSize, openPrice, closePrice, pipValue, direction } = params;
    
    const priceDifference = direction === 'buy' 
      ? closePrice - openPrice 
      : openPrice - closePrice;
    
    const pipDifference = priceDifference / 0.0001; // Convert price difference to pips
    
    return pipDifference * pipValue * lotSize;
  }

  // Calculate compound interest
  static calculateCompounding(params: CompoundingParams): Array<{ month: number; balance: number; totalDeposits: number }> {
    const { initialBalance, monthlyReturn, months, monthlyDeposit = 0 } = params;
    const monthlyRate = monthlyReturn / 100;
    
    const results = [];
    let currentBalance = initialBalance;
    let totalDeposits = initialBalance;
    
    for (let month = 0; month <= months; month++) {
      results.push({
        month,
        balance: Math.round(currentBalance * 100) / 100,
        totalDeposits: Math.round(totalDeposits * 100) / 100,
      });
      
      if (month < months) {
        currentBalance = (currentBalance + monthlyDeposit) * (1 + monthlyRate);
        totalDeposits += monthlyDeposit;
      }
    }
    
    return results;
  }

  // Calculate Fibonacci retracement levels
  static calculateFibonacci(params: FibonacciParams): Record<string, number> {
    const { high, low, direction } = params;
    const difference = high - low;
    
    const levels = {
      '0%': direction === 'uptrend' ? high : low,
      '23.6%': direction === 'uptrend' ? high - (difference * 0.236) : low + (difference * 0.236),
      '38.2%': direction === 'uptrend' ? high - (difference * 0.382) : low + (difference * 0.382),
      '50%': direction === 'uptrend' ? high - (difference * 0.5) : low + (difference * 0.5),
      '61.8%': direction === 'uptrend' ? high - (difference * 0.618) : low + (difference * 0.618),
      '78.6%': direction === 'uptrend' ? high - (difference * 0.786) : low + (difference * 0.786),
      '100%': direction === 'uptrend' ? low : high,
    };

    // Round to 5 decimal places
    Object.keys(levels).forEach(key => {
      levels[key] = Math.round(levels[key] * 100000) / 100000;
    });

    return levels;
  }

  // Calculate pivot points
  static calculatePivotPoints(params: PivotPointsParams): Record<string, number> {
    const { high, low, close, method } = params;
    
    let pivot: number;
    
    if (method === 'standard') {
      pivot = (high + low + close) / 3;
    } else { // DeMark
      if (close < open) {
        pivot = (high + (2 * low) + close) / 4;
      } else if (close > open) {
        pivot = ((2 * high) + low + close) / 4;
      } else {
        pivot = (high + low + (2 * close)) / 4;
      }
    }

    const levels = {
      'PP': pivot,
      'R1': (2 * pivot) - low,
      'R2': pivot + (high - low),
      'R3': high + (2 * (pivot - low)),
      'S1': (2 * pivot) - high,
      'S2': pivot - (high - low),
      'S3': low - (2 * (high - pivot)),
    };

    // Round to 5 decimal places
    Object.keys(levels).forEach(key => {
      levels[key] = Math.round(levels[key] * 100000) / 100000;
    });

    return levels;
  }

  // Calculate risk of ruin
  static calculateRiskOfRuin(winRate: number, avgWin: number, avgLoss: number, riskPercent: number): number {
    const winProbability = winRate / 100;
    const lossProbability = 1 - winProbability;
    
    if (winProbability === 0) return 100;
    if (lossProbability === 0) return 0;
    
    const a = avgLoss / avgWin;
    const p = winProbability;
    const q = lossProbability;
    
    if (a * q >= p) return 100;
    
    const riskOfRuin = Math.pow((q / p) * a, 100 / riskPercent);
    
    return Math.min(Math.round(riskOfRuin * 10000) / 100, 100);
  }

  // Calculate drawdown impact
  static calculateDrawdown(initialBalance: number, lossPercent: number): { 
    newBalance: number; 
    recoveryRequired: number; 
    recoveryPercent: number; 
  } {
    const lossAmount = (initialBalance * lossPercent) / 100;
    const newBalance = initialBalance - lossAmount;
    const recoveryRequired = lossAmount;
    const recoveryPercent = (recoveryRequired / newBalance) * 100;
    
    return {
      newBalance: Math.round(newBalance * 100) / 100,
      recoveryRequired: Math.round(recoveryRequired * 100) / 100,
      recoveryPercent: Math.round(recoveryPercent * 100) / 100,
    };
  }
}
