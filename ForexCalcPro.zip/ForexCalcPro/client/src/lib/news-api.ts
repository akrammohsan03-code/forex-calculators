// Forex News API Integration
interface NewsArticle {
  id: string;
  title: string;
  description: string;
  url: string;
  urlToImage?: string;
  publishedAt: string;
  source: string;
  category: 'forex' | 'economic' | 'central-bank' | 'market' | 'analysis';
  impact: 'low' | 'medium' | 'high';
  currencies?: string[];
}

interface NewsResponse {
  articles: NewsArticle[];
  totalResults: number;
  status: string;
}

class NewsAPI {
  private baseUrl = '/api/news';

  // Get latest forex news
  async getForexNews(limit: number = 20): Promise<NewsArticle[]> {
    try {
      const response = await fetch(`${this.baseUrl}/forex?limit=${limit}`);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data: NewsResponse = await response.json();
      return data.articles;
    } catch (error) {
      console.error('Error fetching forex news:', error);
      return [];
    }
  }

  // Get news by category
  async getNewsByCategory(category: string, limit: number = 10): Promise<NewsArticle[]> {
    try {
      const response = await fetch(`${this.baseUrl}/category/${category}?limit=${limit}`);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data: NewsResponse = await response.json();
      return data.articles;
    } catch (error) {
      console.error(`Error fetching ${category} news:`, error);
      return [];
    }
  }

  // Get news by currency pair
  async getNewsByCurrency(currency: string, limit: number = 10): Promise<NewsArticle[]> {
    try {
      const response = await fetch(`${this.baseUrl}/currency/${currency}?limit=${limit}`);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data: NewsResponse = await response.json();
      return data.articles;
    } catch (error) {
      console.error(`Error fetching news for ${currency}:`, error);
      return [];
    }
  }

  // Search news
  async searchNews(query: string, limit: number = 10): Promise<NewsArticle[]> {
    try {
      const response = await fetch(`${this.baseUrl}/search?q=${encodeURIComponent(query)}&limit=${limit}`);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data: NewsResponse = await response.json();
      return data.articles;
    } catch (error) {
      console.error('Error searching news:', error);
      return [];
    }
  }

  // Format time ago
  formatTimeAgo(dateString: string): string {
    const now = new Date();
    const publishTime = new Date(dateString);
    const diffMs = now.getTime() - publishTime.getTime();
    
    const minutes = Math.floor(diffMs / (1000 * 60));
    const hours = Math.floor(diffMs / (1000 * 60 * 60));
    const days = Math.floor(diffMs / (1000 * 60 * 60 * 24));

    if (minutes < 60) {
      return `${minutes} minutes ago`;
    } else if (hours < 24) {
      return `${hours} hours ago`;
    } else {
      return `${days} days ago`;
    }
  }

  // Get impact badge color
  getImpactColor(impact: string): string {
    switch (impact) {
      case 'high':
        return 'bg-red-100 text-red-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'low':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  }
}

export const newsAPI = new NewsAPI();
export type { NewsArticle, NewsResponse };