import { useState } from 'react';
import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import SEOHead from '@/components/seo-head';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { PieChart, Target, BarChart3 } from 'lucide-react';
import { forexAPI } from '@/lib/forex-api';
import { CalculatorUtils } from '@/lib/calculator-utils';
import { useToast } from '@/hooks/use-toast';

export default function PivotCalculator() {
  const [method, setMethod] = useState<'standard' | 'demark'>('standard');
  const [high, setHigh] = useState<string>('');
  const [low, setLow] = useState<string>('');
  const [close, setClose] = useState<string>('');
  const [open, setOpen] = useState<string>(''); // Only needed for DeMark method
  const [results, setResults] = useState<Record<string, number> | null>(null);
  
  const { toast } = useToast();

  const calculatePivotPoints = async () => {
    const highPrice = parseFloat(high);
    const lowPrice = parseFloat(low);
    const closePrice = parseFloat(close);
    
    if (!highPrice || !lowPrice || !closePrice) {
      toast({
        title: 'Invalid Input',
        description: 'Please enter valid values for high, low, and close prices.',
        variant: 'destructive',
      });
      return;
    }

    if (highPrice < lowPrice || closePrice > highPrice || closePrice < lowPrice) {
      toast({
        title: 'Invalid Price Range',
        description: 'Please ensure high ≥ close ≥ low for valid price data.',
        variant: 'destructive',
      });
      return;
    }

    try {
      const pivotLevels = CalculatorUtils.calculatePivotPoints({
        high: highPrice,
        low: lowPrice,
        close: closePrice,
        method,
      });

      setResults(pivotLevels);

      // Save calculation result
      await forexAPI.saveCalculatorResult('pivot-points', {
        high: highPrice,
        low: lowPrice,
        close: closePrice,
        open: parseFloat(open) || 0,
        method,
      }, pivotLevels);

      toast({
        title: 'Calculation Complete',
        description: 'Pivot points calculated successfully!',
      });

    } catch (error) {
      toast({
        title: 'Calculation Error',
        description: 'Failed to calculate pivot points. Please try again.',
        variant: 'destructive',
      });
    }
  };

  const pivotLevels = [
    { key: 'R3', label: 'Resistance 3', color: 'text-red-600', type: 'resistance' },
    { key: 'R2', label: 'Resistance 2', color: 'text-red-500', type: 'resistance' },
    { key: 'R1', label: 'Resistance 1', color: 'text-red-400', type: 'resistance' },
    { key: 'PP', label: 'Pivot Point', color: 'text-blue-600', type: 'pivot' },
    { key: 'S1', label: 'Support 1', color: 'text-green-400', type: 'support' },
    { key: 'S2', label: 'Support 2', color: 'text-green-500', type: 'support' },
    { key: 'S3', label: 'Support 3', color: 'text-green-600', type: 'support' },
  ];

  return (
    <>
      <SEOHead
        title="Pivot Points Calculator | Calculate Support & Resistance Levels - ForexCalculatorPro"
        description="Free pivot points calculator for forex trading. Calculate standard and DeMark pivot points, support and resistance levels using previous day's high, low, and close prices."
        keywords="pivot points calculator, support resistance calculator, pivot point trading, DeMark pivot points, forex pivot levels"
        canonicalUrl="https://forexcalculatorpro.com/pivot-calculator"
      />

      <div className="min-h-screen bg-navy-50">
        <Header />

        {/* Hero Section */}
        <section className="navy-gradient text-white py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                Professional <span className="text-gold-400">Pivot Points Calculator</span>
              </h1>
              <p className="text-xl mb-8 text-navy-100 max-w-3xl mx-auto">
                Calculate support and resistance levels using standard and DeMark pivot point methods. 
                Essential tool for identifying key price levels in your trading strategy.
              </p>
            </div>
          </div>
        </section>

        {/* Main Calculator Section */}
        <section className="py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Calculator Card */}
              <div className="lg:col-span-2">
                <Card className="calculator-card">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <div className="bg-gold-500 p-2 rounded-lg mr-3">
                        <PieChart className="w-6 h-6 text-white" />
                      </div>
                      Pivot Points Calculator
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      {/* Method Selection */}
                      <div className="space-y-2 md:col-span-2">
                        <Label htmlFor="method">Calculation Method</Label>
                        <Select value={method} onValueChange={(value: 'standard' | 'demark') => setMethod(value)}>
                          <SelectTrigger className="input-field">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="standard">
                              Standard Pivot Points
                            </SelectItem>
                            <SelectItem value="demark">
                              DeMark Pivot Points
                            </SelectItem>
                          </SelectContent>
                        </Select>
                        <div className="text-xs text-navy-600">
                          {method === 'standard' 
                            ? 'Classic pivot point calculation using (H + L + C) / 3'
                            : 'DeMark method considers the relationship between open and close prices'
                          }
                        </div>
                      </div>

                      {/* High Price */}
                      <div className="space-y-2">
                        <Label htmlFor="high">High Price</Label>
                        <Input
                          id="high"
                          type="number"
                          placeholder="1.2000"
                          step="0.00001"
                          value={high}
                          onChange={(e) => setHigh(e.target.value)}
                          className="input-field"
                        />
                        <div className="text-xs text-navy-600">
                          Previous period's highest price
                        </div>
                      </div>

                      {/* Low Price */}
                      <div className="space-y-2">
                        <Label htmlFor="low">Low Price</Label>
                        <Input
                          id="low"
                          type="number"
                          placeholder="1.1800"
                          step="0.00001"
                          value={low}
                          onChange={(e) => setLow(e.target.value)}
                          className="input-field"
                        />
                        <div className="text-xs text-navy-600">
                          Previous period's lowest price
                        </div>
                      </div>

                      {/* Close Price */}
                      <div className="space-y-2">
                        <Label htmlFor="close">Close Price</Label>
                        <Input
                          id="close"
                          type="number"
                          placeholder="1.1950"
                          step="0.00001"
                          value={close}
                          onChange={(e) => setClose(e.target.value)}
                          className="input-field"
                        />
                        <div className="text-xs text-navy-600">
                          Previous period's closing price
                        </div>
                      </div>

                      {/* Open Price (DeMark only) */}
                      {method === 'demark' && (
                        <div className="space-y-2">
                          <Label htmlFor="open">Open Price</Label>
                          <Input
                            id="open"
                            type="number"
                            placeholder="1.1900"
                            step="0.00001"
                            value={open}
                            onChange={(e) => setOpen(e.target.value)}
                            className="input-field"
                          />
                          <div className="text-xs text-navy-600">
                            Required for DeMark calculation
                          </div>
                        </div>
                      )}
                    </div>

                    <Button 
                      onClick={calculatePivotPoints}
                      className="btn-primary w-full"
                    >
                      <PieChart className="w-5 h-5 mr-2" />
                      Calculate Pivot Points
                    </Button>

                    {/* Results Panel */}
                    {results && (
                      <div className="mt-8 p-6 bg-navy-50 rounded-lg">
                        <h3 className="text-lg font-semibold text-navy-900 mb-4">
                          {method === 'standard' ? 'Standard' : 'DeMark'} Pivot Points
                        </h3>
                        
                        {/* Levels Table */}
                        <div className="overflow-x-auto">
                          <table className="w-full">
                            <thead>
                              <tr className="border-b">
                                <th className="text-left py-3 text-navy-700 font-semibold">Level</th>
                                <th className="text-left py-3 text-navy-700 font-semibold">Price</th>
                                <th className="text-left py-3 text-navy-700 font-semibold">Type</th>
                                <th className="text-left py-3 text-navy-700 font-semibold">Distance</th>
                              </tr>
                            </thead>
                            <tbody>
                              {pivotLevels.map((level) => {
                                const price = results[level.key];
                                const pivotPrice = results['PP'];
                                const distance = Math.abs(price - pivotPrice);
                                
                                return (
                                  <tr key={level.key} className="border-b hover:bg-navy-25">
                                    <td className="py-3">
                                      <span className={`font-semibold ${level.color}`}>
                                        {level.key}
                                      </span>
                                    </td>
                                    <td className="py-3 font-mono text-lg">
                                      {price?.toFixed(5)}
                                    </td>
                                    <td className="py-3 text-sm capitalize">
                                      {level.type}
                                    </td>
                                    <td className="py-3 text-sm text-navy-600">
                                      {level.key !== 'PP' ? `${distance.toFixed(5)} pips` : '-'}
                                    </td>
                                  </tr>
                                );
                              })}
                            </tbody>
                          </table>
                        </div>

                        {/* Key Levels Highlight */}
                        <div className="mt-6 p-4 bg-white rounded-lg border">
                          <h4 className="font-semibold text-navy-900 mb-3">Key Trading Levels</h4>
                          <div className="grid md:grid-cols-3 gap-4">
                            <div className="text-center">
                              <div className="text-2xl font-bold text-red-500">
                                {results['R1']?.toFixed(5)}
                              </div>
                              <div className="text-sm text-navy-600">First Resistance</div>
                            </div>
                            <div className="text-center">
                              <div className="text-2xl font-bold text-blue-600">
                                {results['PP']?.toFixed(5)}
                              </div>
                              <div className="text-sm text-navy-600">Pivot Point</div>
                            </div>
                            <div className="text-center">
                              <div className="text-2xl font-bold text-green-500">
                                {results['S1']?.toFixed(5)}
                              </div>
                              <div className="text-sm text-navy-600">First Support</div>
                            </div>
                          </div>
                        </div>

                        {/* Price Input Summary */}
                        <div className="mt-4 p-4 bg-gold-50 rounded-lg">
                          <h4 className="font-semibold text-navy-900 mb-2">Input Summary</h4>
                          <div className="grid md:grid-cols-4 gap-4 text-sm">
                            <div><strong>High:</strong> {high}</div>
                            <div><strong>Low:</strong> {low}</div>
                            <div><strong>Close:</strong> {close}</div>
                            <div><strong>Range:</strong> {(parseFloat(high) - parseFloat(low)).toFixed(5)}</div>
                          </div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Educational Content */}
                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>Understanding Pivot Points</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4 text-sm text-navy-600">
                    <p>
                      Pivot points are technical analysis indicators used to determine the overall trend and 
                      potential support/resistance levels for the next trading period.
                    </p>
                    <div className="space-y-2">
                      <h4 className="font-semibold text-navy-900">How to Use Pivot Points:</h4>
                      <ul className="list-disc pl-5 space-y-1">
                        <li><strong>Above Pivot Point:</strong> Bullish sentiment, look for long opportunities</li>
                        <li><strong>Below Pivot Point:</strong> Bearish sentiment, look for short opportunities</li>
                        <li><strong>Support Levels (S1, S2, S3):</strong> Potential buying opportunities</li>
                        <li><strong>Resistance Levels (R1, R2, R3):</strong> Potential selling opportunities</li>
                      </ul>
                    </div>
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <p className="text-blue-800">
                        <strong>Standard vs DeMark:</strong> Standard pivots use simple averages, while DeMark 
                        pivots adjust based on the relationship between opening and closing prices.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Side Panel */}
              <div className="space-y-6">
                {/* Quick Examples */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Example Data</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button
                      variant="outline"
                      className="w-full text-left justify-start"
                      onClick={() => {
                        setHigh('1.2000');
                        setLow('1.1800');
                        setClose('1.1950');
                        setOpen('1.1850');
                      }}
                    >
                      EUR/USD Daily
                      <div className="text-xs text-navy-500 ml-auto">H: 1.2000 L: 1.1800</div>
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full text-left justify-start"
                      onClick={() => {
                        setHigh('150.50');
                        setLow('149.20');
                        setClose('149.80');
                        setOpen('149.50');
                      }}
                    >
                      USD/JPY Daily
                      <div className="text-xs text-navy-500 ml-auto">H: 150.50 L: 149.20</div>
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full text-left justify-start"
                      onClick={() => {
                        setHigh('2100.00');
                        setLow('2080.00');
                        setClose('2095.00');
                        setOpen('2085.00');
                      }}
                    >
                      Gold Daily
                      <div className="text-xs text-navy-500 ml-auto">H: 2100 L: 2080</div>
                    </Button>
                  </CardContent>
                </Card>

                {/* Trading Strategies */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Trading Strategies</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 text-sm text-navy-600">
                      <div className="flex items-start">
                        <div className="w-2 h-2 bg-green-500 rounded-full mr-3 mt-2"></div>
                        <div>
                          <strong>Pivot Bounce:</strong> Buy at support levels, sell at resistance levels
                        </div>
                      </div>
                      <div className="flex items-start">
                        <div className="w-2 h-2 bg-blue-500 rounded-full mr-3 mt-2"></div>
                        <div>
                          <strong>Breakout:</strong> Trade breaks above/below pivot levels
                        </div>
                      </div>
                      <div className="flex items-start">
                        <div className="w-2 h-2 bg-yellow-500 rounded-full mr-3 mt-2"></div>
                        <div>
                          <strong>Range Trading:</strong> Buy at S1, sell at R1 in sideways markets
                        </div>
                      </div>
                      <div className="flex items-start">
                        <div className="w-2 h-2 bg-purple-500 rounded-full mr-3 mt-2"></div>
                        <div>
                          <strong>Trend Following:</strong> Use pivot as trend direction indicator
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Method Comparison */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Method Comparison</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4 text-sm text-navy-600">
                      <div>
                        <strong className="text-navy-900">Standard Pivots</strong>
                        <p>Simple calculation: (H + L + C) / 3</p>
                        <p>Most widely used method</p>
                      </div>
                      <div>
                        <strong className="text-navy-900">DeMark Pivots</strong>
                        <p>Considers open-close relationship</p>
                        <p>More responsive to gap openings</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}
