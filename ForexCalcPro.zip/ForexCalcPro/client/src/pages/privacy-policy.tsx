import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import SEOHead from '@/components/seo-head';
import { Shield, Eye, Lock, Database } from 'lucide-react';

export default function PrivacyPolicy() {
  return (
    <>
      <SEOHead
        title="Privacy Policy - ForexCalculatorPro"
        description="Privacy Policy for ForexCalculatorPro. Learn how we protect your data and respect your privacy while using our trading calculators and tools."
        canonicalUrl="https://forexcalculatorpro.com/privacy-policy"
      />
      
      <div className="min-h-screen bg-navy-50">
        <Header />

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="bg-white rounded-lg shadow-lg p-8 md:p-12">
            <div className="flex items-center mb-8">
              <div className="bg-gold-500 p-3 rounded-lg mr-4">
                <Shield className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-3xl md:text-4xl font-bold text-navy-900">Privacy Policy</h1>
                <p className="text-navy-600 mt-2">Last updated: {new Date().toLocaleDateString()}</p>
              </div>
            </div>

            <div className="prose max-w-none">
              <div className="grid md:grid-cols-3 gap-6 mb-8">
                <div className="text-center p-4 bg-gray-50 rounded-lg">
                  <Eye className="w-8 h-8 text-gold-500 mx-auto mb-2" />
                  <h3 className="font-semibold text-navy-900">Transparency</h3>
                  <p className="text-sm text-navy-600">Clear about data collection</p>
                </div>
                <div className="text-center p-4 bg-gray-50 rounded-lg">
                  <Lock className="w-8 h-8 text-gold-500 mx-auto mb-2" />
                  <h3 className="font-semibold text-navy-900">Security</h3>
                  <p className="text-sm text-navy-600">Your data is protected</p>
                </div>
                <div className="text-center p-4 bg-gray-50 rounded-lg">
                  <Database className="w-8 h-8 text-gold-500 mx-auto mb-2" />
                  <h3 className="font-semibold text-navy-900">Control</h3>
                  <p className="text-sm text-navy-600">You control your information</p>
                </div>
              </div>

              <div className="space-y-8">
                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">1. Introduction</h2>
                  <p className="text-navy-700 leading-relaxed">
                    ForexCalculatorPro ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website and use our trading calculators and tools.
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">2. Information We Collect</h2>
                  
                  <h3 className="text-xl font-semibold text-navy-900 mb-3">2.1 Information You Provide</h3>
                  <ul className="list-disc list-inside text-navy-700 space-y-2 mb-4">
                    <li>Contact information when you reach out to us</li>
                    <li>Calculator inputs and preferences you choose to save</li>
                    <li>Feedback and suggestions you provide</li>
                  </ul>

                  <h3 className="text-xl font-semibold text-navy-900 mb-3">2.2 Automatically Collected Information</h3>
                  <ul className="list-disc list-inside text-navy-700 space-y-2">
                    <li>IP address and location data</li>
                    <li>Browser type and version</li>
                    <li>Device information and screen resolution</li>
                    <li>Pages visited and time spent on site</li>
                    <li>Referral source and exit pages</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">3. How We Use Your Information</h2>
                  <ul className="list-disc list-inside text-navy-700 space-y-2">
                    <li>To provide and maintain our trading calculator services</li>
                    <li>To improve and optimize our website performance</li>
                    <li>To respond to your inquiries and provide customer support</li>
                    <li>To analyze usage patterns and enhance user experience</li>
                    <li>To send updates about our services (with your consent)</li>
                    <li>To comply with legal obligations and protect our rights</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">4. Information Sharing and Disclosure</h2>
                  <p className="text-navy-700 leading-relaxed mb-4">
                    We do not sell, trade, or rent your personal information to third parties. We may share your information only in the following circumstances:
                  </p>
                  <ul className="list-disc list-inside text-navy-700 space-y-2">
                    <li>With your explicit consent</li>
                    <li>To comply with legal requirements or court orders</li>
                    <li>To protect our rights, property, or safety</li>
                    <li>With service providers who assist in website operations (under strict confidentiality agreements)</li>
                    <li>In connection with a business transfer or merger</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">5. Data Security</h2>
                  <p className="text-navy-700 leading-relaxed">
                    We implement appropriate technical and organizational security measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction. However, no internet transmission is completely secure, and we cannot guarantee absolute security.
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">6. Cookies and Tracking Technologies</h2>
                  <p className="text-navy-700 leading-relaxed mb-4">
                    We use cookies and similar technologies to enhance your browsing experience:
                  </p>
                  <ul className="list-disc list-inside text-navy-700 space-y-2">
                    <li><strong>Essential Cookies:</strong> Required for website functionality</li>
                    <li><strong>Analytics Cookies:</strong> Help us understand how visitors use our site</li>
                    <li><strong>Preference Cookies:</strong> Remember your settings and choices</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">7. Your Privacy Rights</h2>
                  <p className="text-navy-700 leading-relaxed mb-4">You have the right to:</p>
                  <ul className="list-disc list-inside text-navy-700 space-y-2">
                    <li>Access the personal information we hold about you</li>
                    <li>Request correction of inaccurate or incomplete data</li>
                    <li>Request deletion of your personal information</li>
                    <li>Object to or restrict certain processing activities</li>
                    <li>Withdraw consent where we rely on it for processing</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">8. Third-Party Links</h2>
                  <p className="text-navy-700 leading-relaxed">
                    Our website may contain links to third-party sites. We are not responsible for the privacy practices of these external sites. We encourage you to review their privacy policies before providing any information.
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">9. Children's Privacy</h2>
                  <p className="text-navy-700 leading-relaxed">
                    Our services are not intended for individuals under 18 years of age. We do not knowingly collect personal information from children under 18. If we become aware of such collection, we will delete the information immediately.
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">10. Changes to This Policy</h2>
                  <p className="text-navy-700 leading-relaxed">
                    We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new policy on this page and updating the "Last updated" date. We encourage you to review this policy periodically.
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">11. Contact Information</h2>
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <p className="text-navy-700 leading-relaxed mb-4">
                      If you have any questions or concerns about this Privacy Policy, please contact us:
                    </p>
                    <div className="space-y-2 text-navy-700">
                      <p><strong>Email:</strong> akrammohsan03@gmail.com</p>
                      <p><strong>Address:</strong> House 456, Street No 11, J2 Block, Johar Town, Lahore, Pakistan</p>
                      <p><strong>Website:</strong> forexcalculatorpro.com</p>
                    </div>
                  </div>
                </section>
              </div>
            </div>
          </div>
        </div>

        <Footer />
      </div>
    </>
  );
}