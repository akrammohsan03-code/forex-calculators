import { useState } from 'react';
import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import SEOHead from '@/components/seo-head';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Target, TrendingUp, TrendingDown } from 'lucide-react';
import { forexAPI } from '@/lib/forex-api';
import { CalculatorUtils } from '@/lib/calculator-utils';
import { useToast } from '@/hooks/use-toast';

export default function FibonacciCalculator() {
  const [direction, setDirection] = useState<'uptrend' | 'downtrend'>('uptrend');
  const [high, setHigh] = useState<string>('');
  const [low, setLow] = useState<string>('');
  const [results, setResults] = useState<Record<string, number> | null>(null);
  
  const { toast } = useToast();

  const calculateFibonacci = async () => {
    const highPrice = parseFloat(high);
    const lowPrice = parseFloat(low);
    
    if (!highPrice || !lowPrice || highPrice <= lowPrice) {
      toast({
        title: 'Invalid Input',
        description: 'Please enter valid high and low prices (high must be greater than low).',
        variant: 'destructive',
      });
      return;
    }

    try {
      const fibonacciLevels = CalculatorUtils.calculateFibonacci({
        high: highPrice,
        low: lowPrice,
        direction,
      });

      setResults(fibonacciLevels);

      // Save calculation result
      await forexAPI.saveCalculatorResult('fibonacci', {
        high: highPrice,
        low: lowPrice,
        direction,
      }, fibonacciLevels);

      toast({
        title: 'Calculation Complete',
        description: 'Fibonacci levels calculated successfully!',
      });

    } catch (error) {
      toast({
        title: 'Calculation Error',
        description: 'Failed to calculate Fibonacci levels. Please try again.',
        variant: 'destructive',
      });
    }
  };

  const fibonacciLevels = [
    { key: '0%', label: '0% (Start)', color: 'text-red-600' },
    { key: '23.6%', label: '23.6% Retracement', color: 'text-orange-600' },
    { key: '38.2%', label: '38.2% Retracement', color: 'text-yellow-600' },
    { key: '50%', label: '50% Retracement', color: 'text-blue-600' },
    { key: '61.8%', label: '61.8% Retracement', color: 'text-green-600' },
    { key: '78.6%', label: '78.6% Retracement', color: 'text-purple-600' },
    { key: '100%', label: '100% (End)', color: 'text-gray-600' },
  ];

  return (
    <>
      <SEOHead
        title="Fibonacci Calculator | Calculate Retracement & Extension Levels - ForexCalculatorPro"
        description="Free Fibonacci calculator for forex, stocks, and crypto. Calculate Fibonacci retracement and extension levels for technical analysis. Essential tool for traders."
        keywords="fibonacci calculator, fibonacci retracement, technical analysis, trading levels, support resistance, fibonacci extension"
        canonicalUrl="https://forexcalculatorpro.com/fibonacci-calculator"
      />

      <div className="min-h-screen bg-navy-50">
        <Header />

        {/* Hero Section */}
        <section className="navy-gradient text-white py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                Professional <span className="text-gold-400">Fibonacci Calculator</span>
              </h1>
              <p className="text-xl mb-8 text-navy-100 max-w-3xl mx-auto">
                Calculate Fibonacci retracement and extension levels for technical analysis across all markets. 
                Identify key support and resistance levels for better trading decisions.
              </p>
            </div>
          </div>
        </section>

        {/* Main Calculator Section */}
        <section className="py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Calculator Card */}
              <div className="lg:col-span-2">
                <Card className="calculator-card">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <div className="bg-gold-500 p-2 rounded-lg mr-3">
                        <Target className="w-6 h-6 text-white" />
                      </div>
                      Fibonacci Retracement Calculator
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      {/* Trend Direction */}
                      <div className="space-y-2 md:col-span-2">
                        <Label htmlFor="direction">Trend Direction</Label>
                        <Select value={direction} onValueChange={(value: 'uptrend' | 'downtrend') => setDirection(value)}>
                          <SelectTrigger className="input-field">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="uptrend">
                              <div className="flex items-center">
                                <TrendingUp className="w-4 h-4 mr-2 text-green-500" />
                                Uptrend (Bullish Retracement)
                              </div>
                            </SelectItem>
                            <SelectItem value="downtrend">
                              <div className="flex items-center">
                                <TrendingDown className="w-4 h-4 mr-2 text-red-500" />
                                Downtrend (Bearish Retracement)
                              </div>
                            </SelectItem>
                          </SelectContent>
                        </Select>
                        <div className="text-xs text-navy-600">
                          {direction === 'uptrend' 
                            ? 'Select uptrend for measuring retracement from high to low in an upward move'
                            : 'Select downtrend for measuring retracement from low to high in a downward move'
                          }
                        </div>
                      </div>

                      {/* High Price */}
                      <div className="space-y-2">
                        <Label htmlFor="high">High Price</Label>
                        <Input
                          id="high"
                          type="number"
                          placeholder="1.2000"
                          step="0.00001"
                          value={high}
                          onChange={(e) => setHigh(e.target.value)}
                          className="input-field"
                        />
                        <div className="text-xs text-navy-600">
                          The highest price point in the move
                        </div>
                      </div>

                      {/* Low Price */}
                      <div className="space-y-2">
                        <Label htmlFor="low">Low Price</Label>
                        <Input
                          id="low"
                          type="number"
                          placeholder="1.1500"
                          step="0.00001"
                          value={low}
                          onChange={(e) => setLow(e.target.value)}
                          className="input-field"
                        />
                        <div className="text-xs text-navy-600">
                          The lowest price point in the move
                        </div>
                      </div>
                    </div>

                    <Button 
                      onClick={calculateFibonacci}
                      className="btn-primary w-full"
                    >
                      <Target className="w-5 h-5 mr-2" />
                      Calculate Fibonacci Levels
                    </Button>

                    {/* Results Panel */}
                    {results && (
                      <div className="mt-8 p-6 bg-navy-50 rounded-lg">
                        <h3 className="text-lg font-semibold text-navy-900 mb-4">Fibonacci Retracement Levels</h3>
                        
                        {/* Levels Table */}
                        <div className="overflow-x-auto">
                          <table className="w-full">
                            <thead>
                              <tr className="border-b">
                                <th className="text-left py-3 text-navy-700 font-semibold">Level</th>
                                <th className="text-left py-3 text-navy-700 font-semibold">Price</th>
                                <th className="text-left py-3 text-navy-700 font-semibold">Significance</th>
                              </tr>
                            </thead>
                            <tbody>
                              {fibonacciLevels.map((level) => (
                                <tr key={level.key} className="border-b hover:bg-navy-25">
                                  <td className="py-3">
                                    <span className={`font-semibold ${level.color}`}>
                                      {level.key}
                                    </span>
                                  </td>
                                  <td className="py-3 font-mono text-lg">
                                    {results[level.key]?.toFixed(5)}
                                  </td>
                                  <td className="py-3 text-sm text-navy-600">
                                    {level.label}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>

                        {/* Key Levels Highlight */}
                        <div className="mt-6 p-4 bg-white rounded-lg border">
                          <h4 className="font-semibold text-navy-900 mb-3">Most Important Levels</h4>
                          <div className="grid md:grid-cols-3 gap-4">
                            <div className="text-center">
                              <div className="text-2xl font-bold text-yellow-600">
                                {results['38.2%']?.toFixed(5)}
                              </div>
                              <div className="text-sm text-navy-600">38.2% - Shallow Retracement</div>
                            </div>
                            <div className="text-center">
                              <div className="text-2xl font-bold text-blue-600">
                                {results['50%']?.toFixed(5)}
                              </div>
                              <div className="text-sm text-navy-600">50% - Psychological Level</div>
                            </div>
                            <div className="text-center">
                              <div className="text-2xl font-bold text-green-600">
                                {results['61.8%']?.toFixed(5)}
                              </div>
                              <div className="text-sm text-navy-600">61.8% - Golden Ratio</div>
                            </div>
                          </div>
                        </div>

                        {/* Range Information */}
                        <div className="mt-4 p-4 bg-gold-50 rounded-lg">
                          <div className="grid md:grid-cols-2 gap-4 text-sm">
                            <div>
                              <strong>Price Range:</strong> {Math.abs(parseFloat(high) - parseFloat(low)).toFixed(5)}
                            </div>
                            <div>
                              <strong>Trend Direction:</strong> {direction === 'uptrend' ? '📈 Bullish' : '📉 Bearish'}
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Educational Content */}
                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>Understanding Fibonacci Retracements</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4 text-sm text-navy-600">
                    <p>
                      Fibonacci retracements are horizontal lines that indicate areas of support or resistance 
                      at the key Fibonacci levels before the price continues in the original direction.
                    </p>
                    <div className="space-y-2">
                      <h4 className="font-semibold text-navy-900">Key Levels Explained:</h4>
                      <ul className="list-disc pl-5 space-y-1">
                        <li><strong>23.6%:</strong> Shallow retracement, strong trend continuation likely</li>
                        <li><strong>38.2%:</strong> Moderate retracement, first significant support/resistance</li>
                        <li><strong>50%:</strong> Not a Fibonacci ratio, but psychologically important level</li>
                        <li><strong>61.8%:</strong> Golden ratio, most important Fibonacci level</li>
                        <li><strong>78.6%:</strong> Deep retracement, trend may be weakening</li>
                      </ul>
                    </div>
                    <div className="bg-gold-50 p-4 rounded-lg">
                      <p className="text-gold-800">
                        <strong>Trading Tip:</strong> The 61.8% level (golden ratio) is often considered 
                        the most reliable for trend continuation trades.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Side Panel */}
              <div className="space-y-6">
                {/* Quick Examples */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Example Setups</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button
                      variant="outline"
                      className="w-full text-left justify-start"
                      onClick={() => {
                        setHigh('1.2000');
                        setLow('1.1500');
                        setDirection('uptrend');
                      }}
                    >
                      EUR/USD Uptrend
                      <div className="text-xs text-navy-500 ml-auto">1.2000 - 1.1500</div>
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full text-left justify-start"
                      onClick={() => {
                        setHigh('150.00');
                        setLow('148.50');
                        setDirection('downtrend');
                      }}
                    >
                      USD/JPY Downtrend
                      <div className="text-xs text-navy-500 ml-auto">150.00 - 148.50</div>
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full text-left justify-start"
                      onClick={() => {
                        setHigh('2100.00');
                        setLow('2050.00');
                        setDirection('uptrend');
                      }}
                    >
                      Gold Uptrend
                      <div className="text-xs text-navy-500 ml-auto">2100 - 2050</div>
                    </Button>
                  </CardContent>
                </Card>

                {/* Trading Guidelines */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Trading Guidelines</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 text-sm text-navy-600">
                      <div className="flex items-start">
                        <div className="w-2 h-2 bg-green-500 rounded-full mr-3 mt-2"></div>
                        <div>
                          <strong>Entry:</strong> Look for price reactions at key Fibonacci levels
                        </div>
                      </div>
                      <div className="flex items-start">
                        <div className="w-2 h-2 bg-blue-500 rounded-full mr-3 mt-2"></div>
                        <div>
                          <strong>Confirmation:</strong> Use candlestick patterns or other indicators
                        </div>
                      </div>
                      <div className="flex items-start">
                        <div className="w-2 h-2 bg-yellow-500 rounded-full mr-3 mt-2"></div>
                        <div>
                          <strong>Stop Loss:</strong> Place beyond the next Fibonacci level
                        </div>
                      </div>
                      <div className="flex items-start">
                        <div className="w-2 h-2 bg-purple-500 rounded-full mr-3 mt-2"></div>
                        <div>
                          <strong>Target:</strong> Aim for previous high/low or extension levels
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Fibonacci Ratios */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Fibonacci Sequence</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-sm text-navy-600">
                      <p className="mb-3">The Fibonacci sequence: 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89...</p>
                      <div className="space-y-2">
                        <div><strong>23.6%</strong> = 1 - 0.764 (76.4%)</div>
                        <div><strong>38.2%</strong> = 1 - 0.618 (61.8%)</div>
                        <div><strong>61.8%</strong> = Golden Ratio (φ)</div>
                        <div><strong>78.6%</strong> = √0.618</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}
