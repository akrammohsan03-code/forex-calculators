import { useState, useEffect } from 'react';
import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import SEOHead from '@/components/seo-head';
import ForexNewsFeed from '@/components/forex-news-feed';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import { Newspaper, Globe, TrendingUp, Clock, Bell, Settings, Mail, Zap } from 'lucide-react';

export default function ForexNews() {
  const [isNotificationDialogOpen, setIsNotificationDialogOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [notifications, setNotifications] = useState({
    breakingNews: true,
    economicEvents: true,
    centralBankNews: true,
    marketAnalysis: false,
    browserNotifications: false
  });
  const { toast } = useToast();

  // Check for existing subscription on component mount
  useEffect(() => {
    const savedSubscription = localStorage.getItem('newsNotifications');
    if (savedSubscription) {
      const subscription = JSON.parse(savedSubscription);
      setEmail(subscription.email);
      setNotifications(subscription.preferences);
      setIsSubscribed(true);
    }
  }, []);

  const handleSubscribe = async () => {
    if (!email || !email.includes('@')) {
      toast({
        title: "Invalid Email",
        description: "Please enter a valid email address.",
        variant: "destructive"
      });
      return;
    }

    // Request browser notification permission if enabled
    if (notifications.browserNotifications && 'Notification' in window) {
      const permission = await Notification.requestPermission();
      if (permission !== 'granted') {
        toast({
          title: "Browser Notifications",
          description: "Browser notifications were not enabled. Email notifications will still work.",
          variant: "default"
        });
      }
    }

    // Save notification preferences to localStorage
    localStorage.setItem('newsNotifications', JSON.stringify({
      email,
      preferences: notifications,
      subscribedAt: new Date().toISOString()
    }));

    // Show demo notification if browser notifications are enabled
    if (notifications.browserNotifications && 'Notification' in window && Notification.permission === 'granted') {
      setTimeout(() => {
        new Notification('ForexCalculatorPro News Alert', {
          body: 'Welcome! You\'ll now receive breaking market news notifications.',
          icon: '/favicon.ico',
          tag: 'welcome-notification'
        });
      }, 2000);
    }

    toast({
      title: "Subscription Successful!",
      description: "You'll receive market news notifications based on your preferences.",
      variant: "default"
    });

    setIsSubscribed(true);
    setIsNotificationDialogOpen(false);
  };

  const handleUnsubscribe = () => {
    localStorage.removeItem('newsNotifications');
    setIsSubscribed(false);
    setEmail('');
    setNotifications({
      breakingNews: true,
      economicEvents: true,
      centralBankNews: true,
      marketAnalysis: false,
      browserNotifications: false
    });
    
    toast({
      title: "Unsubscribed Successfully",
      description: "You will no longer receive news notifications.",
      variant: "default"
    });
    
    setIsNotificationDialogOpen(false);
  };

  return (
    <>
      <SEOHead 
        title="Forex Market News | Real-Time Financial News | ForexCalculatorPro"
        description="Stay updated with the latest forex market news, economic events, and central bank announcements. Real-time financial news with market impact analysis."
        keywords="forex news, market news, economic calendar, central bank news, financial news, currency market updates"
      />
      
      <div className="min-h-screen bg-white">
        <Header />

        {/* Hero Section */}
        <section className="py-16 navy-gradient text-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-4xl font-bold mb-6">
              Forex Market News & Analysis
            </h1>
            <p className="text-xl text-navy-100 max-w-3xl mx-auto mb-8">
              Stay ahead of market movements with real-time forex news, economic events, and expert analysis 
              from trusted financial sources worldwide.
            </p>
            <div className="flex flex-col items-center space-y-6">
              <div className="flex justify-center space-x-4">
                <Badge variant="secondary" className="px-4 py-2">
                  <Clock className="w-4 h-4 mr-2" />
                  Real-time Updates
                </Badge>
                <Badge variant="secondary" className="px-4 py-2">
                  <Globe className="w-4 h-4 mr-2" />
                  Global Coverage
                </Badge>
                <Badge variant="secondary" className="px-4 py-2">
                  <TrendingUp className="w-4 h-4 mr-2" />
                  Market Impact
                </Badge>
              </div>
              
              {/* Notification Status and Subscription Button */}
              <div className="flex flex-col items-center space-y-3">
                {isSubscribed && (
                  <div className="flex items-center space-x-2 bg-green-100 text-green-800 px-4 py-2 rounded-full text-sm font-medium">
                    <Zap className="w-4 h-4" />
                    <span>News alerts active for {email}</span>
                  </div>
                )}
                
                <Dialog open={isNotificationDialogOpen} onOpenChange={setIsNotificationDialogOpen}>
                  <DialogTrigger asChild>
                    <Button className="bg-gold-500 hover:bg-gold-600 text-white px-8 py-3 text-lg font-semibold rounded-lg shadow-lg hover:shadow-xl transition-all duration-200">
                      {isSubscribed ? (
                        <>
                          <Settings className="w-5 h-5 mr-2" />
                          Manage Alerts
                        </>
                      ) : (
                        <>
                          <Bell className="w-5 h-5 mr-2" />
                          Get News Alerts
                        </>
                      )}
                    </Button>
                  </DialogTrigger>
                <DialogContent className="sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle className="flex items-center">
                      <Bell className="w-5 h-5 mr-2 text-gold-500" />
                      News Alert Notifications
                    </DialogTitle>
                    <DialogDescription>
                      Stay informed with instant alerts for breaking market news and important economic events.
                    </DialogDescription>
                  </DialogHeader>
                  
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="your.email@example.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                      />
                    </div>
                    
                    <div className="space-y-3">
                      <Label>Notification Preferences</Label>
                      
                      <div className="flex items-center justify-between">
                        <div className="space-y-1">
                          <Label htmlFor="breaking-news" className="text-sm font-medium">Breaking News</Label>
                          <p className="text-xs text-gray-600">High-impact market events</p>
                        </div>
                        <Switch
                          id="breaking-news"
                          checked={notifications.breakingNews}
                          onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, breakingNews: checked }))}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="space-y-1">
                          <Label htmlFor="economic-events" className="text-sm font-medium">Economic Events</Label>
                          <p className="text-xs text-gray-600">GDP, inflation, employment data</p>
                        </div>
                        <Switch
                          id="economic-events"
                          checked={notifications.economicEvents}
                          onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, economicEvents: checked }))}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="space-y-1">
                          <Label htmlFor="central-bank" className="text-sm font-medium">Central Bank News</Label>
                          <p className="text-xs text-gray-600">Fed, ECB, BOJ announcements</p>
                        </div>
                        <Switch
                          id="central-bank"
                          checked={notifications.centralBankNews}
                          onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, centralBankNews: checked }))}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="space-y-1">
                          <Label htmlFor="market-analysis" className="text-sm font-medium">Market Analysis</Label>
                          <p className="text-xs text-gray-600">Expert insights and forecasts</p>
                        </div>
                        <Switch
                          id="market-analysis"
                          checked={notifications.marketAnalysis}
                          onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, marketAnalysis: checked }))}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="space-y-1">
                          <Label htmlFor="browser-notifications" className="text-sm font-medium">Browser Notifications</Label>
                          <p className="text-xs text-gray-600">Instant desktop alerts</p>
                        </div>
                        <Switch
                          id="browser-notifications"
                          checked={notifications.browserNotifications}
                          onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, browserNotifications: checked }))}
                        />
                      </div>
                    </div>
                  </div>
                  
                  <DialogFooter className="sm:justify-start">
                    <div className="flex space-x-3 w-full">
                      <Button type="button" onClick={handleSubscribe} className="flex-1 bg-gold-500 hover:bg-gold-600">
                        <Mail className="w-4 h-4 mr-2" />
                        {isSubscribed ? 'Update Preferences' : 'Subscribe to Alerts'}
                      </Button>
                      {isSubscribed && (
                        <Button type="button" variant="outline" onClick={handleUnsubscribe} className="border-red-200 text-red-600 hover:bg-red-50">
                          Unsubscribe
                        </Button>
                      )}
                    </div>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
              </div>
            </div>
          </div>
        </section>

        {/* News Feed */}
        <section className="py-16">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <ForexNewsFeed 
              compact={false}
              showSearch={true}
              maxArticles={50}
            />
          </div>
        </section>

        {/* News Categories */}
        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-navy-900 mb-4">News Categories</h2>
              <p className="text-lg text-navy-600 max-w-3xl mx-auto">
                Comprehensive coverage across all major market-moving news categories
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-6">
              <div className="text-center">
                <div className="bg-blue-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-navy-900 mb-2">Forex</h3>
                <p className="text-sm text-navy-600">
                  Currency pair analysis and trading opportunities
                </p>
              </div>

              <div className="text-center">
                <div className="bg-green-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Globe className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-navy-900 mb-2">Economic</h3>
                <p className="text-sm text-navy-600">
                  Economic indicators and government data releases
                </p>
              </div>

              <div className="text-center">
                <div className="bg-purple-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Newspaper className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-navy-900 mb-2">Central Bank</h3>
                <p className="text-sm text-navy-600">
                  Federal Reserve, ECB, and BoE policy decisions
                </p>
              </div>

              <div className="text-center">
                <div className="bg-orange-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-navy-900 mb-2">Market</h3>
                <p className="text-sm text-navy-600">
                  Stock market, commodities, and crypto updates
                </p>
              </div>

              <div className="text-center">
                <div className="bg-gray-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Newspaper className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-navy-900 mb-2">Analysis</h3>
                <p className="text-sm text-navy-600">
                  Technical analysis and expert market commentary
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* News Sources */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-navy-900 mb-4">Trusted News Sources</h2>
              <p className="text-lg text-navy-600 max-w-3xl mx-auto">
                We aggregate news from the most respected financial news organizations and market analysts
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-8 items-center">
              {[
                'Reuters', 'Bloomberg', 'Financial Times', 'MarketWatch', 
                'FXStreet', 'DailyFX', 'CNBC', 'ECB Press', 'Fed Reserve', 'Bank of England'
              ].map((source) => (
                <div key={source} className="text-center">
                  <div className="bg-gray-100 p-4 rounded-lg">
                    <h4 className="font-semibold text-gray-800">{source}</h4>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}