import { useState } from 'react';
import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import SEOHead from '@/components/seo-head';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { AlertTriangle, TrendingDown, TrendingUp, Calculator } from 'lucide-react';
import { forexAPI } from '@/lib/forex-api';
import { CalculatorUtils } from '@/lib/calculator-utils';
import { useToast } from '@/hooks/use-toast';

interface DrawdownResult {
  newBalance: number;
  recoveryRequired: number;
  recoveryPercent: number;
}

export default function DrawdownCalculator() {
  const [initialBalance, setInitialBalance] = useState<string>('10000');
  const [lossPercentage, setLossPercentage] = useState<string>('20');
  const [result, setResult] = useState<DrawdownResult | null>(null);
  const [multipleDrawdowns, setMultipleDrawdowns] = useState<Array<{ balance: number; loss: number; recovery: number }> | null>(null);
  
  const { toast } = useToast();

  const calculateDrawdown = async () => {
    const balance = parseFloat(initialBalance);
    const loss = parseFloat(lossPercentage);
    
    if (!balance || !loss || balance <= 0 || loss < 0 || loss >= 100) {
      toast({
        title: 'Invalid Input',
        description: 'Please enter a valid balance and loss percentage (0-99%).',
        variant: 'destructive',
      });
      return;
    }

    try {
      const drawdownResult = CalculatorUtils.calculateDrawdown(balance, loss);
      setResult(drawdownResult);

      // Calculate multiple drawdown scenarios
      const scenarios = [];
      let currentBalance = balance;
      
      for (let i = 5; i <= 50; i += 5) {
        const scenario = CalculatorUtils.calculateDrawdown(balance, i);
        scenarios.push({
          balance: scenario.newBalance,
          loss: i,
          recovery: scenario.recoveryPercent,
        });
      }
      setMultipleDrawdowns(scenarios);

      // Save calculation result
      await forexAPI.saveCalculatorResult('drawdown', {
        initialBalance: balance,
        lossPercentage: loss,
      }, drawdownResult);

      toast({
        title: 'Calculation Complete',
        description: 'Drawdown analysis calculated successfully!',
      });

    } catch (error) {
      toast({
        title: 'Calculation Error',
        description: 'Failed to calculate drawdown. Please try again.',
        variant: 'destructive',
      });
    }
  };

  return (
    <>
      <SEOHead
        title="Drawdown Calculator | Calculate Trading Losses & Recovery Requirements - ForexCalculatorPro"
        description="Free drawdown calculator to analyze how losses affect your trading account. Calculate recovery requirements and understand the impact of drawdowns on your capital."
        keywords="drawdown calculator, trading losses calculator, recovery calculator, account drawdown, trading risk management, equity recovery"
        canonicalUrl="https://forexcalculatorpro.com/drawdown-calculator"
      />

      <div className="min-h-screen bg-navy-50">
        <Header />

        {/* Hero Section */}
        <section className="navy-gradient text-white py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                Professional <span className="text-gold-400">Drawdown Calculator</span>
              </h1>
              <p className="text-xl mb-8 text-navy-100 max-w-3xl mx-auto">
                Calculate how your account equity is affected after a series of losing trades and determine 
                the percentage gain required to recover from drawdowns.
              </p>
            </div>
          </div>
        </section>

        {/* Main Calculator Section */}
        <section className="py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Calculator Card */}
              <div className="lg:col-span-2">
                <Card className="calculator-card">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <div className="bg-gold-500 p-2 rounded-lg mr-3">
                        <AlertTriangle className="w-6 h-6 text-white" />
                      </div>
                      Account Drawdown Calculator
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      {/* Initial Balance */}
                      <div className="space-y-2">
                        <Label htmlFor="initialBalance">Initial Account Balance ($)</Label>
                        <Input
                          id="initialBalance"
                          type="number"
                          placeholder="10000"
                          value={initialBalance}
                          onChange={(e) => setInitialBalance(e.target.value)}
                          className="input-field"
                        />
                      </div>

                      {/* Loss Percentage */}
                      <div className="space-y-2">
                        <Label htmlFor="lossPercentage">Drawdown Percentage (%)</Label>
                        <Input
                          id="lossPercentage"
                          type="number"
                          placeholder="20"
                          step="0.1"
                          min="0"
                          max="99"
                          value={lossPercentage}
                          onChange={(e) => setLossPercentage(e.target.value)}
                          className="input-field"
                        />
                        <div className="text-xs text-navy-600">
                          Percentage of account lost in drawdown
                        </div>
                      </div>
                    </div>

                    <Button 
                      onClick={calculateDrawdown}
                      className="btn-primary w-full"
                    >
                      <AlertTriangle className="w-5 h-5 mr-2" />
                      Calculate Drawdown Impact
                    </Button>

                    {/* Results Panel */}
                    {result && (
                      <div className="mt-8 p-6 bg-navy-50 rounded-lg">
                        <h3 className="text-lg font-semibold text-navy-900 mb-4">Drawdown Analysis Results</h3>
                        
                        {/* Main Results */}
                        <div className="grid md:grid-cols-3 gap-4 mb-6">
                          <Card className="border">
                            <CardContent className="p-4 text-center">
                              <div className="text-2xl font-bold text-red-600">
                                ${result.newBalance.toFixed(2)}
                              </div>
                              <div className="text-sm text-navy-600">Balance After Loss</div>
                            </CardContent>
                          </Card>
                          <Card className="border">
                            <CardContent className="p-4 text-center">
                              <div className="text-2xl font-bold text-orange-600">
                                ${result.recoveryRequired.toFixed(2)}
                              </div>
                              <div className="text-sm text-navy-600">Recovery Amount</div>
                            </CardContent>
                          </Card>
                          <Card className="border">
                            <CardContent className="p-4 text-center">
                              <div className="text-2xl font-bold text-green-600">
                                +{result.recoveryPercent.toFixed(1)}%
                              </div>
                              <div className="text-sm text-navy-600">Recovery Required</div>
                            </CardContent>
                          </Card>
                        </div>

                        {/* Visual Representation */}
                        <div className="grid md:grid-cols-2 gap-6 mb-6">
                          <Card className="border">
                            <CardContent className="p-4">
                              <h4 className="font-semibold text-navy-900 mb-3 flex items-center">
                                <TrendingDown className="w-4 h-4 mr-2 text-red-500" />
                                Drawdown Impact
                              </h4>
                              <div className="space-y-2 text-sm">
                                <div className="flex justify-between">
                                  <span>Initial Balance:</span>
                                  <span className="font-semibold">${parseFloat(initialBalance).toFixed(2)}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span>Loss ({lossPercentage}%):</span>
                                  <span className="text-red-600 font-semibold">-${result.recoveryRequired.toFixed(2)}</span>
                                </div>
                                <div className="flex justify-between border-t pt-2">
                                  <span>Remaining Balance:</span>
                                  <span className="font-semibold">${result.newBalance.toFixed(2)}</span>
                                </div>
                              </div>
                            </CardContent>
                          </Card>

                          <Card className="border">
                            <CardContent className="p-4">
                              <h4 className="font-semibold text-navy-900 mb-3 flex items-center">
                                <TrendingUp className="w-4 h-4 mr-2 text-green-500" />
                                Recovery Requirements
                              </h4>
                              <div className="space-y-2 text-sm">
                                <div className="flex justify-between">
                                  <span>Current Balance:</span>
                                  <span className="font-semibold">${result.newBalance.toFixed(2)}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span>Target Balance:</span>
                                  <span className="font-semibold">${parseFloat(initialBalance).toFixed(2)}</span>
                                </div>
                                <div className="flex justify-between border-t pt-2">
                                  <span>Gain Required:</span>
                                  <span className="text-green-600 font-semibold">+{result.recoveryPercent.toFixed(1)}%</span>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        </div>

                        {/* Warning for High Drawdowns */}
                        {parseFloat(lossPercentage) >= 50 && (
                          <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                            <div className="flex items-center text-red-800">
                              <AlertTriangle className="w-5 h-5 mr-2" />
                              <strong>High Drawdown Warning</strong>
                            </div>
                            <p className="text-red-700 text-sm mt-1">
                              A {lossPercentage}% drawdown requires a {result.recoveryPercent.toFixed(1)}% gain to recover. 
                              Large drawdowns become exponentially harder to recover from.
                            </p>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Multiple Drawdown Scenarios */}
                    {multipleDrawdowns && (
                      <div className="mt-8 p-6 bg-white rounded-lg border">
                        <h3 className="text-lg font-semibold text-navy-900 mb-4">Drawdown Recovery Table</h3>
                        <div className="overflow-x-auto">
                          <table className="w-full text-sm">
                            <thead>
                              <tr className="border-b">
                                <th className="text-left py-2 text-navy-700">Drawdown</th>
                                <th className="text-left py-2 text-navy-700">Balance After</th>
                                <th className="text-left py-2 text-navy-700">Recovery Required</th>
                                <th className="text-left py-2 text-navy-700">Difficulty</th>
                              </tr>
                            </thead>
                            <tbody>
                              {multipleDrawdowns.map((scenario) => (
                                <tr key={scenario.loss} className="border-b">
                                  <td className="py-2 text-red-600 font-semibold">-{scenario.loss}%</td>
                                  <td className="py-2">${scenario.balance.toFixed(2)}</td>
                                  <td className="py-2 text-green-600 font-semibold">+{scenario.recovery.toFixed(1)}%</td>
                                  <td className="py-2">
                                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                      scenario.recovery <= 25 ? 'bg-green-100 text-green-800' :
                                      scenario.recovery <= 50 ? 'bg-yellow-100 text-yellow-800' :
                                      scenario.recovery <= 100 ? 'bg-orange-100 text-orange-800' :
                                      'bg-red-100 text-red-800'
                                    }`}>
                                      {scenario.recovery <= 25 ? 'Easy' :
                                       scenario.recovery <= 50 ? 'Moderate' :
                                       scenario.recovery <= 100 ? 'Hard' : 'Very Hard'}
                                    </span>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Educational Content */}
                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>Understanding Drawdowns</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4 text-sm text-navy-600">
                    <p>
                      A drawdown is the peak-to-trough decline during a specific period of an investment or trading account. 
                      It's typically quoted as the percentage between the peak and the trough.
                    </p>
                    <div className="space-y-2">
                      <h4 className="font-semibold text-navy-900">Key Points:</h4>
                      <ul className="list-disc pl-5 space-y-1">
                        <li>A 50% loss requires a 100% gain to recover</li>
                        <li>Large drawdowns are exponentially harder to recover from</li>
                        <li>Maximum drawdown is a key risk metric for traders</li>
                        <li>Proper position sizing can help limit drawdowns</li>
                      </ul>
                    </div>
                    <div className="bg-red-50 p-4 rounded-lg">
                      <p className="text-red-800">
                        <strong>Risk Warning:</strong> Never risk more than you can afford to lose. 
                        A series of losses can quickly compound into significant drawdowns.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Side Panel */}
              <div className="space-y-6">
                {/* Quick Scenarios */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Common Scenarios</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button
                      variant="outline"
                      className="w-full text-left justify-start"
                      onClick={() => {
                        setInitialBalance('10000');
                        setLossPercentage('10');
                      }}
                    >
                      Conservative Loss
                      <div className="text-xs text-navy-500 ml-auto">10% drawdown</div>
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full text-left justify-start"
                      onClick={() => {
                        setInitialBalance('10000');
                        setLossPercentage('25');
                      }}
                    >
                      Moderate Loss
                      <div className="text-xs text-navy-500 ml-auto">25% drawdown</div>
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full text-left justify-start"
                      onClick={() => {
                        setInitialBalance('10000');
                        setLossPercentage('50');
                      }}
                    >
                      Severe Loss
                      <div className="text-xs text-navy-500 ml-auto">50% drawdown</div>
                    </Button>
                  </CardContent>
                </Card>

                {/* Related Tools */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Related Tools</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <a href="/position-size-calculator" className="flex items-center p-3 hover:bg-navy-50 rounded-lg transition-colors group">
                      <div className="bg-gold-100 p-2 rounded mr-3 group-hover:bg-gold-200">
                        <Calculator className="w-4 h-4 text-gold-600" />
                      </div>
                      <span className="text-navy-700 font-medium">Position Size Calculator</span>
                    </a>
                    <a href="/risk-of-ruin-calculator" className="flex items-center p-3 hover:bg-navy-50 rounded-lg transition-colors group">
                      <div className="bg-gold-100 p-2 rounded mr-3 group-hover:bg-gold-200">
                        <AlertTriangle className="w-4 h-4 text-gold-600" />
                      </div>
                      <span className="text-navy-700 font-medium">Risk of Ruin Calculator</span>
                    </a>
                    <a href="/compounding-calculator" className="flex items-center p-3 hover:bg-navy-50 rounded-lg transition-colors group">
                      <div className="bg-gold-100 p-2 rounded mr-3 group-hover:bg-gold-200">
                        <TrendingUp className="w-4 h-4 text-gold-600" />
                      </div>
                      <span className="text-navy-700 font-medium">Compounding Calculator</span>
                    </a>
                  </CardContent>
                </Card>

                {/* Recovery Tips */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Recovery Tips</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 text-sm text-navy-600">
                      <div className="flex items-start">
                        <div className="w-2 h-2 bg-green-500 rounded-full mr-3 mt-2"></div>
                        <div>
                          <strong>Reduce Risk:</strong> Lower position sizes after significant losses
                        </div>
                      </div>
                      <div className="flex items-start">
                        <div className="w-2 h-2 bg-blue-500 rounded-full mr-3 mt-2"></div>
                        <div>
                          <strong>Stay Disciplined:</strong> Don't increase risk to recover faster
                        </div>
                      </div>
                      <div className="flex items-start">
                        <div className="w-2 h-2 bg-yellow-500 rounded-full mr-3 mt-2"></div>
                        <div>
                          <strong>Take Breaks:</strong> Avoid emotional trading after losses
                        </div>
                      </div>
                      <div className="flex items-start">
                        <div className="w-2 h-2 bg-purple-500 rounded-full mr-3 mt-2"></div>
                        <div>
                          <strong>Review Strategy:</strong> Analyze what caused the drawdown
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}
