import { useState, useEffect } from 'react';
import { Calendar, Clock, TrendingUp, AlertTriangle, Star, ChevronLeft, ChevronRight, Filter, ExternalLink } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

interface EconomicEvent {
  id: string;
  time: string;
  currency: string;
  event: string;
  importance: 'low' | 'medium' | 'high';
  actual: string;
  forecast: string;
  previous: string;
  impact: 'positive' | 'negative' | 'neutral';
}

const mockEconomicData: EconomicEvent[] = [
  {
    id: '1',
    time: '08:30',
    currency: 'USD',
    event: 'Non-Farm Payrolls',
    importance: 'high',
    actual: '263K',
    forecast: '200K',
    previous: '315K',
    impact: 'positive'
  },
  {
    id: '2',
    time: '10:00',
    currency: 'EUR',
    event: 'German ZEW Economic Sentiment',
    importance: 'high',
    actual: '19.2',
    forecast: '15.0',
    previous: '12.8',
    impact: 'positive'
  },
  {
    id: '3',
    time: '12:30',
    currency: 'GBP',
    event: 'BoE Interest Rate Decision',
    importance: 'high',
    actual: '5.25%',
    forecast: '5.25%',
    previous: '5.00%',
    impact: 'neutral'
  },
  {
    id: '4',
    time: '14:00',
    currency: 'USD',
    event: 'Core CPI MoM',
    importance: 'high',
    actual: '0.3%',
    forecast: '0.2%',
    previous: '0.1%',
    impact: 'positive'
  },
  {
    id: '5',
    time: '09:00',
    currency: 'JPY',
    event: 'Core CPI YoY',
    importance: 'medium',
    actual: '2.8%',
    forecast: '2.9%',
    previous: '3.1%',
    impact: 'negative'
  },
  {
    id: '6',
    time: '16:30',
    currency: 'USD',
    event: 'Crude Oil Inventories',
    importance: 'medium',
    actual: '-2.4M',
    forecast: '-1.5M',
    previous: '+0.8M',
    impact: 'positive'
  },
  {
    id: '7',
    time: '02:00',
    currency: 'GBP',
    event: 'Claimant Count Change',
    importance: 'medium',
    actual: '-25.9K',
    forecast: '-6.2K',
    previous: '19.7K',
    impact: 'positive'
  },
  {
    id: '8',
    time: '05:00',
    currency: 'EUR',
    event: 'Italy Balance of Trade',
    importance: 'low',
    actual: '€-1.71B',
    forecast: '€5.409B',
    previous: '€6.103B',
    impact: 'negative'
  }
];

const currencyFilters = [
  { value: 'all', label: 'All Currencies' },
  { value: 'USD', label: 'USD - US Dollar' },
  { value: 'EUR', label: 'EUR - Euro' },
  { value: 'GBP', label: 'GBP - British Pound' },
  { value: 'JPY', label: 'JPY - Japanese Yen' },
  { value: 'AUD', label: 'AUD - Australian Dollar' },
  { value: 'CAD', label: 'CAD - Canadian Dollar' },
  { value: 'CHF', label: 'CHF - Swiss Franc' }
];

const importanceFilters = [
  { value: 'all', label: 'All Impact Levels' },
  { value: 'high', label: 'High Impact' },
  { value: 'medium', label: 'Medium Impact' },
  { value: 'low', label: 'Low Impact' }
];

export default function EconomicCalendar() {
  const [events, setEvents] = useState<EconomicEvent[]>(mockEconomicData);
  const [selectedCurrency, setSelectedCurrency] = useState('all');
  const [selectedImportance, setSelectedImportance] = useState('all');
  const [currentTime, setCurrentTime] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const filteredEvents = events.filter(event => {
    const currencyMatch = selectedCurrency === 'all' || event.currency === selectedCurrency;
    const importanceMatch = selectedImportance === 'all' || event.importance === selectedImportance;
    return currencyMatch && importanceMatch;
  });

  const getImportanceIcon = (importance: string) => {
    switch (importance) {
      case 'high': return <div className="w-3 h-3 rounded-full bg-red-500"></div>;
      case 'medium': return <div className="w-3 h-3 rounded-full bg-yellow-500"></div>;
      case 'low': return <div className="w-3 h-3 rounded-full bg-green-500"></div>;
      default: return <div className="w-3 h-3 rounded-full bg-gray-400"></div>;
    }
  };

  const getSurpriseIcon = (actual: string, forecast: string) => {
    if (!actual || !forecast) return null;
    const actualNum = parseFloat(actual.replace(/[^0-9.-]/g, ''));
    const forecastNum = parseFloat(forecast.replace(/[^0-9.-]/g, ''));
    
    if (actualNum > forecastNum) {
      return <TrendingUp className="w-4 h-4 text-green-600" />;
    } else if (actualNum < forecastNum) {
      return <AlertTriangle className="w-4 h-4 text-red-600" />;
    }
    return null;
  };

  const formatDateRange = () => {
    const startDate = new Date(selectedDate);
    const endDate = new Date(selectedDate);
    endDate.setDate(endDate.getDate() + 6);
    
    return `${startDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })} - ${endDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}`;
  };

  const navigateWeek = (direction: 'prev' | 'next') => {
    const newDate = new Date(selectedDate);
    newDate.setDate(newDate.getDate() + (direction === 'next' ? 7 : -7));
    setSelectedDate(newDate);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <Calendar className="w-8 h-8 text-gold-600 mr-3" />
            <div>
              <h1 className="text-3xl font-bold text-navy-900">Forex Economic Calendar</h1>
              <p className="text-navy-600 mt-1">
                Big surprises on medium and high importance events show as larger 'Actual' values. The calendar updates in real-time.
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="text-right">
              <div className="text-2xl font-bold text-gold-600">
                {currentTime.toLocaleTimeString('en-GB', { timeZone: 'GMT' })}
              </div>
              <div className="text-sm text-navy-600">GMT</div>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center"
            >
              <Filter className="w-4 h-4 mr-1" />
              Filter
            </Button>
            <Button variant="outline" size="sm" className="flex items-center">
              <ExternalLink className="w-4 h-4 mr-1" />
              Popout
            </Button>
          </div>
        </div>

        {/* Date Navigation */}
        <div className="flex items-center justify-center mb-6">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigateWeek('prev')}
            className="mr-4"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <div className="text-lg font-semibold text-navy-900 min-w-[300px] text-center">
            {formatDateRange()}
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigateWeek('next')}
            className="ml-4"
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>

        {/* Filters Panel */}
        {showFilters && (
          <Card className="mb-6">
            <CardContent className="p-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-navy-700">Currency:</label>
                  <Select value={selectedCurrency} onValueChange={setSelectedCurrency}>
                    <SelectTrigger className="input-field">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {currencyFilters.map((filter) => (
                        <SelectItem key={filter.value} value={filter.value}>
                          {filter.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium text-navy-700">Impact:</label>
                  <Select value={selectedImportance} onValueChange={setSelectedImportance}>
                    <SelectTrigger className="input-field">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {importanceFilters.map((filter) => (
                        <SelectItem key={filter.value} value={filter.value}>
                          {filter.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Economic Events Table */}
      <Card>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-navy-50">
                <TableHead className="text-center w-20">Date</TableHead>
                <TableHead className="text-center w-20">Time</TableHead>
                <TableHead className="text-center w-24">Time Left</TableHead>
                <TableHead className="text-center w-20">Currency</TableHead>
                <TableHead className="text-center w-16">Impact</TableHead>
                <TableHead className="min-w-[250px]">Event</TableHead>
                <TableHead className="text-center w-20">Surprise</TableHead>
                <TableHead className="text-center w-24">Actual</TableHead>
                <TableHead className="text-center w-24">Forecast</TableHead>
                <TableHead className="text-center w-24">Previous</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredEvents.map((event, index) => (
                <TableRow key={event.id} className="hover:bg-navy-25 transition-colors">
                  <TableCell className="text-center text-sm">
                    <div className="font-medium">
                      {index === 0 ? 'Today' : 'Mon'}
                    </div>
                    <div className="text-xs text-navy-600">
                      Aug {14 + index}
                    </div>
                  </TableCell>
                  <TableCell className="text-center font-mono text-sm">
                    {event.time}
                  </TableCell>
                  <TableCell className="text-center text-sm text-navy-600">
                    --
                  </TableCell>
                  <TableCell className="text-center">
                    <Badge variant="outline" className="text-xs font-bold">
                      {event.currency}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-center">
                    {getImportanceIcon(event.importance)}
                  </TableCell>
                  <TableCell>
                    <div className="font-medium text-navy-900 text-sm hover:text-gold-600 cursor-pointer">
                      {event.event}
                    </div>
                  </TableCell>
                  <TableCell className="text-center">
                    {getSurpriseIcon(event.actual, event.forecast)}
                  </TableCell>
                  <TableCell className="text-center font-semibold text-sm">
                    <span className={event.actual ? (
                      parseFloat(event.actual.replace(/[^0-9.-]/g, '')) > parseFloat((event.forecast || '0').replace(/[^0-9.-]/g, '')) 
                        ? 'text-green-700 bg-green-50 px-2 py-1 rounded' 
                        : parseFloat(event.actual.replace(/[^0-9.-]/g, '')) < parseFloat((event.forecast || '0').replace(/[^0-9.-]/g, ''))
                        ? 'text-red-700 bg-red-50 px-2 py-1 rounded'
                        : 'text-navy-700'
                    ) : 'text-navy-400'}>
                      {event.actual || 'TBA'}
                    </span>
                  </TableCell>
                  <TableCell className="text-center text-sm text-navy-700">
                    {event.forecast || 'N/A'}
                  </TableCell>
                  <TableCell className="text-center text-sm text-navy-600">
                    {event.previous || 'N/A'}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </Card>

      {filteredEvents.length === 0 && (
        <Card className="mt-6">
          <CardContent className="text-center py-12">
            <Calendar className="w-16 h-16 text-navy-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-navy-600 mb-2">No Events Found</h3>
            <p className="text-navy-500">
              No economic events match your current filters. Try adjusting your selection.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Impact Legend */}
      <Card className="mt-6 bg-navy-50">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-6">
              <div className="flex items-center">
                <div className="w-3 h-3 bg-red-500 rounded-full mr-2"></div>
                <span className="text-sm font-medium">High Impact</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 bg-yellow-500 rounded-full mr-2"></div>
                <span className="text-sm font-medium">Medium Impact</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                <span className="text-sm font-medium">Low Impact</span>
              </div>
            </div>
            <div className="text-xs text-navy-600">
              Updates every 30 seconds • All times are GMT
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}