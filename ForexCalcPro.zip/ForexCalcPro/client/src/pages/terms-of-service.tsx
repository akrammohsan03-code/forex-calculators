import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import SEOHead from '@/components/seo-head';
import { FileText, AlertTriangle, Scale, CheckCircle } from 'lucide-react';

export default function TermsOfService() {
  return (
    <>
      <SEOHead
        title="Terms of Service - ForexCalculatorPro"
        description="Terms of Service for ForexCalculatorPro. Read our terms and conditions for using our trading calculators and financial tools."
        canonicalUrl="https://forexcalculatorpro.com/terms-of-service"
      />
      
      <div className="min-h-screen bg-navy-50">
        <Header />

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="bg-white rounded-lg shadow-lg p-8 md:p-12">
            <div className="flex items-center mb-8">
              <div className="bg-gold-500 p-3 rounded-lg mr-4">
                <FileText className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-3xl md:text-4xl font-bold text-navy-900">Terms of Service</h1>
                <p className="text-navy-600 mt-2">Last updated: {new Date().toLocaleDateString()}</p>
              </div>
            </div>

            <div className="prose max-w-none">
              <div className="grid md:grid-cols-3 gap-6 mb-8">
                <div className="text-center p-4 bg-gray-50 rounded-lg">
                  <Scale className="w-8 h-8 text-gold-500 mx-auto mb-2" />
                  <h3 className="font-semibold text-navy-900">Fair Use</h3>
                  <p className="text-sm text-navy-600">Clear terms and conditions</p>
                </div>
                <div className="text-center p-4 bg-gray-50 rounded-lg">
                  <CheckCircle className="w-8 h-8 text-gold-500 mx-auto mb-2" />
                  <h3 className="font-semibold text-navy-900">Agreement</h3>
                  <p className="text-sm text-navy-600">Your acceptance of terms</p>
                </div>
                <div className="text-center p-4 bg-gray-50 rounded-lg">
                  <AlertTriangle className="w-8 h-8 text-gold-500 mx-auto mb-2" />
                  <h3 className="font-semibold text-navy-900">Disclaimer</h3>
                  <p className="text-sm text-navy-600">Important limitations</p>
                </div>
              </div>

              <div className="space-y-8">
                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">1. Agreement to Terms</h2>
                  <p className="text-navy-700 leading-relaxed">
                    By accessing and using ForexCalculatorPro ("Service," "we," "us," or "our"), you accept and agree to be bound by the terms and provision of this agreement. If you do not agree to abide by the above, please do not use this service.
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">2. Description of Service</h2>
                  <p className="text-navy-700 leading-relaxed mb-4">
                    ForexCalculatorPro provides online trading calculators and tools for:
                  </p>
                  <ul className="list-disc list-inside text-navy-700 space-y-2">
                    <li>Position size calculation and risk management</li>
                    <li>Pip value calculation for various currency pairs</li>
                    <li>Profit and loss calculation for trading positions</li>
                    <li>Margin requirements and leverage calculations</li>
                    <li>Currency conversion and exchange rates</li>
                    <li>Various other financial and trading tools</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">3. Educational Purpose Only</h2>
                  <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-4">
                    <div className="flex">
                      <AlertTriangle className="w-6 h-6 text-yellow-400 mr-3 mt-0.5" />
                      <div>
                        <p className="text-navy-700 leading-relaxed">
                          <strong>Important Notice:</strong> All calculators and tools provided are for educational and informational purposes only. They are not intended as investment advice or recommendations for trading decisions.
                        </p>
                      </div>
                    </div>
                  </div>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">4. User Responsibilities</h2>
                  <p className="text-navy-700 leading-relaxed mb-4">By using our service, you agree to:</p>
                  <ul className="list-disc list-inside text-navy-700 space-y-2">
                    <li>Use the service only for lawful purposes</li>
                    <li>Provide accurate information when using our calculators</li>
                    <li>Not attempt to interfere with or disrupt the service</li>
                    <li>Not use automated systems to access our service without permission</li>
                    <li>Respect intellectual property rights</li>
                    <li>Conduct your own due diligence before making any trading decisions</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">5. Accuracy and Reliability</h2>
                  <p className="text-navy-700 leading-relaxed">
                    While we strive to provide accurate calculations and up-to-date market data, we cannot guarantee the accuracy, completeness, or reliability of any information provided. Market conditions change rapidly, and calculations should be verified independently before making trading decisions.
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">6. Limitation of Liability</h2>
                  <p className="text-navy-700 leading-relaxed mb-4">
                    To the fullest extent permitted by applicable law, ForexCalculatorPro shall not be liable for:
                  </p>
                  <ul className="list-disc list-inside text-navy-700 space-y-2">
                    <li>Any trading losses or financial damages</li>
                    <li>Errors or inaccuracies in calculations or data</li>
                    <li>Service interruptions or technical failures</li>
                    <li>Indirect, incidental, or consequential damages</li>
                    <li>Loss of profits, data, or business opportunities</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">7. Risk Disclosure</h2>
                  <div className="bg-red-50 border-l-4 border-red-400 p-4 mb-4">
                    <div className="flex">
                      <AlertTriangle className="w-6 h-6 text-red-400 mr-3 mt-0.5" />
                      <div>
                        <p className="text-navy-700 leading-relaxed">
                          <strong>Trading Risk Warning:</strong> Trading in foreign exchange, commodities, and other financial instruments involves substantial risk and may not be suitable for all investors. Past performance is not indicative of future results.
                        </p>
                      </div>
                    </div>
                  </div>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">8. Intellectual Property</h2>
                  <p className="text-navy-700 leading-relaxed">
                    The Service and its original content, features, and functionality are and will remain the exclusive property of ForexCalculatorPro and its licensors. The Service is protected by copyright, trademark, and other laws.
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">9. Privacy Policy</h2>
                  <p className="text-navy-700 leading-relaxed">
                    Your privacy is important to us. Please review our Privacy Policy, which also governs your use of the Service, to understand our practices.
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">10. Termination</h2>
                  <p className="text-navy-700 leading-relaxed">
                    We may terminate or suspend access immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms.
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">11. Changes to Terms</h2>
                  <p className="text-navy-700 leading-relaxed">
                    We reserve the right, at our sole discretion, to modify or replace these Terms at any time. If a revision is material, we will try to provide at least 30 days' notice prior to any new terms taking effect.
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">12. Governing Law</h2>
                  <p className="text-navy-700 leading-relaxed">
                    These Terms shall be interpreted and governed by the laws of Pakistan, without regard to its conflict of law provisions.
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">13. Contact Information</h2>
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <p className="text-navy-700 leading-relaxed mb-4">
                      If you have any questions about these Terms of Service, please contact us:
                    </p>
                    <div className="space-y-2 text-navy-700">
                      <p><strong>Email:</strong> akrammohsan03@gmail.com</p>
                      <p><strong>Address:</strong> House 456, Street No 11, J2 Block, Johar Town, Lahore, Pakistan</p>
                      <p><strong>Website:</strong> forexcalculatorpro.com</p>
                    </div>
                  </div>
                </section>
              </div>
            </div>
          </div>
        </div>

        <Footer />
      </div>
    </>
  );
}