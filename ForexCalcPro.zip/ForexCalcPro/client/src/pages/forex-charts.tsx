import { useState } from 'react';
import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import SEOHead from '@/components/seo-head';
import TradingViewChart from '@/components/trading-view-chart';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BarChart3, TrendingUp, Activity, Maximize2, Minimize2 } from 'lucide-react';

export default function ForexCharts() {
  const [fullscreenChart, setFullscreenChart] = useState<string | null>(null);

  const chartConfigs = [
    {
      id: 'eur-usd',
      symbol: 'EUR/USD',
      title: 'Euro vs US Dollar',
      category: 'Major Pair'
    },
    {
      id: 'gbp-usd',
      symbol: 'GBP/USD',
      title: 'British Pound vs US Dollar',
      category: 'Major Pair'
    },
    {
      id: 'usd-jpy',
      symbol: 'USD/JPY',
      title: 'US Dollar vs Japanese Yen',
      category: 'Major Pair'
    },
    {
      id: 'xau-usd',
      symbol: 'XAU/USD',
      title: 'Gold Spot Price',
      category: 'Precious Metal'
    },
    {
      id: 'us100',
      symbol: 'US100',
      title: 'NASDAQ 100 Index',
      category: 'Stock Index'
    },
    {
      id: 'crude-oil',
      symbol: 'CRUDE_OIL',
      title: 'Crude Oil WTI',
      category: 'Energy Commodity'
    }
  ];

  return (
    <>
      <SEOHead 
        title="Live Forex Charts | Real-Time Market Data | ForexCalculatorPro"
        description="Access professional live forex charts with real-time market data. Analyze major currency pairs, commodities, and indices with advanced TradingView charting technology."
        keywords="live forex charts, real-time market data, forex analysis, TradingView charts, currency pairs, commodities trading"
      />
      
      <div className="min-h-screen bg-white">
        <Header />

        {/* Hero Section */}
        <section className="py-16 navy-gradient text-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-4xl font-bold mb-6">
              Live Forex Charts & Market Analysis
            </h1>
            <p className="text-xl text-navy-100 max-w-3xl mx-auto mb-8">
              Professional-grade charting powered by TradingView Lightweight Charts™. 
              Analyze market movements with real-time data across 70+ trading instruments.
            </p>
            <div className="flex justify-center space-x-4">
              <Badge variant="secondary" className="px-4 py-2">
                <Activity className="w-4 h-4 mr-2" />
                Real-time Data
              </Badge>
              <Badge variant="secondary" className="px-4 py-2">
                <BarChart3 className="w-4 h-4 mr-2" />
                Professional Charts
              </Badge>
              <Badge variant="secondary" className="px-4 py-2">
                <TrendingUp className="w-4 h-4 mr-2" />
                Multiple Timeframes
              </Badge>
            </div>
          </div>
        </section>

        {/* Main Chart Section */}
        <section className="py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-navy-900 mb-4">Featured Chart</h2>
              <p className="text-gray-600">
                Primary EUR/USD analysis with full chart controls and real-time updates
              </p>
            </div>

            <TradingViewChart
              symbol="EUR/USD"
              height={500}
              showControls={true}
              isFullscreen={fullscreenChart === 'main'}
              onFullscreenToggle={() => setFullscreenChart(fullscreenChart === 'main' ? null : 'main')}
            />
          </div>
        </section>

        {/* Multiple Charts Grid */}
        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-navy-900 mb-4">Market Overview</h2>
              <p className="text-lg text-navy-600 max-w-3xl mx-auto">
                Monitor multiple markets simultaneously with our comprehensive chart dashboard
              </p>
            </div>

            <div className="grid lg:grid-cols-2 gap-8">
              {chartConfigs.map((config) => (
                <Card key={config.id} className="overflow-hidden">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-lg">{config.title}</CardTitle>
                        <Badge variant="outline" className="mt-1">
                          {config.category}
                        </Badge>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setFullscreenChart(fullscreenChart === config.id ? null : config.id)}
                      >
                        {fullscreenChart === config.id ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="p-0">
                    <TradingViewChart
                      symbol={config.symbol}
                      height={300}
                      showControls={false}
                      isFullscreen={fullscreenChart === config.id}
                      onFullscreenToggle={() => setFullscreenChart(fullscreenChart === config.id ? null : config.id)}
                    />
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Chart Features */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-navy-900 mb-4">Advanced Charting Features</h2>
              <p className="text-lg text-navy-600 max-w-3xl mx-auto">
                Professional trading tools with institutional-grade market data
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="bg-gold-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Activity className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-navy-900 mb-2">Real-Time Updates</h3>
                <p className="text-sm text-navy-600">
                  Live market data with sub-second precision for accurate analysis
                </p>
              </div>

              <div className="text-center">
                <div className="bg-gold-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <BarChart3 className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-navy-900 mb-2">Multiple Timeframes</h3>
                <p className="text-sm text-navy-600">
                  From 1-minute to daily charts for comprehensive market analysis
                </p>
              </div>

              <div className="text-center">
                <div className="bg-gold-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-navy-900 mb-2">Candlestick Analysis</h3>
                <p className="text-sm text-navy-600">
                  Professional OHLC candlestick charts with volume indicators
                </p>
              </div>

              <div className="text-center">
                <div className="bg-gold-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Maximize2 className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-navy-900 mb-2">Fullscreen Mode</h3>
                <p className="text-sm text-navy-600">
                  Distraction-free charting with expandable fullscreen views
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 navy-gradient text-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl font-bold mb-6">
              Ready to Analyze the Markets?
            </h2>
            <p className="text-xl text-navy-100 max-w-3xl mx-auto mb-8">
              Combine professional charting with our comprehensive calculator suite for complete trading analysis
            </p>
            <div className="flex justify-center space-x-4">
              <Button size="lg" className="bg-gold-500 hover:bg-gold-600">
                <a href="/#calculators">View Calculators</a>
              </Button>
              <Button size="lg" variant="outline" className="text-white border-white hover:bg-white hover:text-navy-900">
                <a href="/economic-calendar">Economic Calendar</a>
              </Button>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}