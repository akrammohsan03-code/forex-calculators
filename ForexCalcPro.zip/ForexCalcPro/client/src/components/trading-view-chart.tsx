import { useEffect, useRef, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { createChart, IChartApi, ISeriesApi, ColorType, LineStyle, CandlestickData, Time, CandlestickSeries } from 'lightweight-charts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, Activity, BarChart3, Maximize2, Minimize2, RefreshCw } from 'lucide-react';
import { forexAPI } from '@/lib/forex-api';

interface TradingViewChartProps {
  symbol?: string;
  height?: number;
  showControls?: boolean;
  isFullscreen?: boolean;
  onFullscreenToggle?: () => void;
}

export default function TradingViewChart({ 
  symbol = 'EUR/USD', 
  height = 500, 
  showControls = true,
  isFullscreen = false,
  onFullscreenToggle
}: TradingViewChartProps) {
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const seriesRef = useRef<ISeriesApi<'Candlestick'> | null>(null);
  
  const [selectedSymbol, setSelectedSymbol] = useState(symbol);
  const [timeframe, setTimeframe] = useState('1H');
  const [isLoading, setIsLoading] = useState(false);
  const [currentPrice, setCurrentPrice] = useState<number>(0);
  const [priceChange, setPriceChange] = useState<number>(0);
  const [priceChangePercent, setPriceChangePercent] = useState<number>(0);
  const [isUpdating, setIsUpdating] = useState(false);

  const { data: currencyPairs } = useQuery({
    queryKey: ['/api/currency-pairs'],
    queryFn: () => forexAPI.getCurrencyPairs(),
    refetchInterval: 3000,
  });

  // Initialize chart
  useEffect(() => {
    if (!chartContainerRef.current) return;

    const chart = createChart(chartContainerRef.current, {
      layout: {
        background: { type: ColorType.Solid, color: '#ffffff' },
        textColor: '#1f2937',
        fontSize: 12,
        fontFamily: 'Inter, system-ui, sans-serif',
      },
      width: chartContainerRef.current.clientWidth,
      height: height,
      rightPriceScale: {
        borderVisible: false,
        textColor: '#6b7280',
      },
      timeScale: {
        borderVisible: false,
        timeVisible: true,
        secondsVisible: false,
      },
      crosshair: {
        horzLine: {
          visible: false,
        },
      },
      grid: {
        vertLines: {
          color: '#f3f4f6',
        },
        horzLines: {
          color: '#f3f4f6',
        },
      },
      handleScroll: {
        mouseWheel: true,
        pressedMouseMove: true,
      },
      handleScale: {
        axisPressedMouseMove: true,
        mouseWheel: true,
        pinch: true,
      },
    });

    const candlestickSeries = chart.addSeries(CandlestickSeries, {
      upColor: '#10b981',
      downColor: '#ef4444',
      borderDownColor: '#ef4444',
      borderUpColor: '#10b981',
      wickDownColor: '#ef4444',
      wickUpColor: '#10b981',
    });

    chartRef.current = chart;
    seriesRef.current = candlestickSeries;

    // Cleanup
    return () => {
      chart.remove();
    };
  }, [height]);

  // Generate realistic forex data
  const generateForexData = (symbol: string, timeframe: string) => {
    const data: CandlestickData[] = [];
    const basePrice = symbol.includes('JPY') ? 150.0 : 1.1000;
    let currentPrice = basePrice + (Math.random() - 0.5) * 0.1;
    
    const now = new Date();
    const timeframeMs = getTimeframeMs(timeframe);
    const dataPoints = 200;
    
    for (let i = dataPoints; i >= 0; i--) {
      const time = new Date(now.getTime() - i * timeframeMs);
      const volatility = symbol.includes('JPY') ? 0.5 : 0.003;
      
      const change = (Math.random() - 0.5) * volatility;
      const open = currentPrice;
      const close = currentPrice + change;
      const high = Math.max(open, close) + Math.random() * volatility * 0.3;
      const low = Math.min(open, close) - Math.random() * volatility * 0.3;
      
      data.push({
        time: Math.floor(time.getTime() / 1000) as Time,
        open: Number(open.toFixed(symbol.includes('JPY') ? 3 : 5)),
        high: Number(high.toFixed(symbol.includes('JPY') ? 3 : 5)),
        low: Number(low.toFixed(symbol.includes('JPY') ? 3 : 5)),
        close: Number(close.toFixed(symbol.includes('JPY') ? 3 : 5)),
      });
      
      currentPrice = close;
    }
    
    return data.sort((a, b) => (a.time as number) - (b.time as number));
  };

  const getTimeframeMs = (tf: string): number => {
    switch (tf) {
      case '1M': return 60 * 1000;
      case '5M': return 5 * 60 * 1000;
      case '15M': return 15 * 60 * 1000;
      case '1H': return 60 * 60 * 1000;
      case '4H': return 4 * 60 * 60 * 1000;
      case '1D': return 24 * 60 * 60 * 1000;
      default: return 60 * 60 * 1000;
    }
  };

  // Load chart data
  const loadChartData = async () => {
    if (!seriesRef.current) return;
    
    setIsLoading(true);
    
    try {
      const data = generateForexData(selectedSymbol, timeframe);
      seriesRef.current.setData(data);
      
      if (data.length > 0) {
        const latestCandle = data[data.length - 1];
        const previousCandle = data[data.length - 2];
        
        setCurrentPrice(latestCandle.close);
        const change = latestCandle.close - previousCandle.close;
        const changePercent = (change / previousCandle.close) * 100;
        
        setPriceChange(change);
        setPriceChangePercent(changePercent);
      }
      
    } catch (error) {
      console.error('Error loading chart data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Update chart when symbol or timeframe changes
  useEffect(() => {
    loadChartData();
  }, [selectedSymbol, timeframe]);

  // Update current price from live data
  useEffect(() => {
    if (currencyPairs && seriesRef.current) {
      const pair = currencyPairs.find(p => p.symbol === selectedSymbol);
      if (pair && pair.rate) {
        const newPrice = parseFloat(pair.rate.toString());
        const oldPrice = currentPrice;
        
        if (oldPrice > 0 && Math.abs(newPrice - oldPrice) > 0.00001) {
          setIsUpdating(true);
          
          // Add new data point to chart
          const now = Math.floor(Date.now() / 1000) as Time;
          const lastData = seriesRef.current.dataByIndex(999, 1); // Get last candle
          
          if (lastData) {
            seriesRef.current.update({
              time: now,
              open: oldPrice,
              high: Math.max(oldPrice, newPrice),
              low: Math.min(oldPrice, newPrice),
              close: newPrice,
            });
          }
          
          setTimeout(() => setIsUpdating(false), 1000);
        }
        
        setCurrentPrice(newPrice);
        const change = newPrice - oldPrice;
        const changePercent = oldPrice > 0 ? (change / oldPrice) * 100 : 0;
        
        setPriceChange(change);
        setPriceChangePercent(changePercent);
      }
    }
  }, [currencyPairs, selectedSymbol, currentPrice]);

  // Handle resize
  useEffect(() => {
    const handleResize = () => {
      if (chartRef.current && chartContainerRef.current) {
        chartRef.current.applyOptions({
          width: chartContainerRef.current.clientWidth,
        });
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const pairs = ['EUR/USD', 'GBP/USD', 'USD/JPY', 'USD/CHF', 'AUD/USD', 'USD/CAD', 'NZD/USD', 'XAU/USD', 'XAG/USD', 'CRUDE_OIL', 'US100', 'US30'];
  const timeframes = ['1M', '5M', '15M', '1H', '4H', '1D'];

  return (
    <Card className={`${isFullscreen ? 'fixed inset-4 z-50 max-w-none' : ''} ${isUpdating ? 'ring-2 ring-yellow-400 ring-opacity-50' : ''}`}>
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <CardTitle className="flex items-center">
              <Activity className="w-6 h-6 mr-2 text-gold-500" />
              Live Chart - {selectedSymbol}
              {isUpdating && <Badge variant="secondary" className="ml-2 animate-pulse">LIVE</Badge>}
            </CardTitle>
            
            <div className={`flex items-center space-x-3 px-4 py-2 rounded-lg transition-all duration-300 ${
              isUpdating ? 'bg-yellow-100 scale-105 shadow-lg' : 'bg-gray-50'
            }`}>
              <span className="font-mono text-xl font-bold text-gray-900">
                {currentPrice.toFixed(selectedSymbol.includes('JPY') ? 3 : 5)}
              </span>
              <div className={`flex items-center space-x-1 ${priceChange >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {priceChange >= 0 ? <TrendingUp className="w-5 h-5" /> : <TrendingDown className="w-5 h-5" />}
                <div className="text-sm font-medium">
                  <div>{priceChange >= 0 ? '+' : ''}{priceChange.toFixed(selectedSymbol.includes('JPY') ? 3 : 5)}</div>
                  <div className="text-xs">({priceChangePercent >= 0 ? '+' : ''}{priceChangePercent.toFixed(2)}%)</div>
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={loadChartData}
              disabled={isLoading}
              className="p-2"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            </Button>
            
            {onFullscreenToggle && (
              <Button
                variant="outline"
                size="sm"
                onClick={onFullscreenToggle}
                className="p-2"
              >
                {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              </Button>
            )}
          </div>
        </div>

        {showControls && (
          <div className="flex flex-wrap gap-4 mt-4">
            <Select value={selectedSymbol} onValueChange={setSelectedSymbol}>
              <SelectTrigger className="w-[140px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <div className="px-2 py-1 text-xs font-semibold text-gray-600 bg-gray-50">Major Pairs</div>
                {pairs.slice(0, 7).map((pair) => (
                  <SelectItem key={pair} value={pair}>{pair}</SelectItem>
                ))}
                <div className="px-2 py-1 text-xs font-semibold text-gray-600 bg-gray-50 mt-1">Commodities & Indices</div>
                {pairs.slice(7).map((pair) => (
                  <SelectItem key={pair} value={pair}>{pair}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={timeframe} onValueChange={setTimeframe}>
              <SelectTrigger className="w-[100px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {timeframes.map((tf) => (
                  <SelectItem key={tf} value={tf}>{tf}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Badge variant={isUpdating ? "default" : "secondary"} className="px-3 py-1">
              {isUpdating ? "Updating..." : "Real-time"}
            </Badge>
          </div>
        )}
      </CardHeader>
      
      <CardContent className="pb-4">
        <div 
          ref={chartContainerRef}
          className="relative w-full border rounded-lg bg-white"
          style={{ height: `${height}px` }}
        />
        
        <div className="mt-4 text-xs text-gray-500 text-center">
          Powered by TradingView Lightweight Charts™ • Data updates every 3 seconds
        </div>
      </CardContent>
    </Card>
  );
}