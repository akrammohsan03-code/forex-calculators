import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Menu, X, Calculator, ChevronDown, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import LiveRatesTicker from '@/components/live-rates-ticker';

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [calculatorsDropdownOpen, setCalculatorsDropdownOpen] = useState(false);
  const [mobileCalculatorsOpen, setMobileCalculatorsOpen] = useState(false);
  const [location] = useLocation();

  const navigation = [
    { name: 'Home', href: '/' },
    { 
      name: 'Calculators', 
      href: '/#calculators',
      subItems: [
        { name: 'Position Size Calculator', href: '/position-size-calculator' },
        { name: 'Pip Calculator', href: '/pip-calculator' },
        { name: 'Profit Calculator', href: '/profit-calculator' },
        { name: 'Margin Calculator', href: '/margin-calculator' },
        { name: 'Currency Converter', href: '/currency-converter' },
        { name: 'Compounding Calculator', href: '/compounding-calculator' },
        { name: 'Fibonacci Calculator', href: '/fibonacci-calculator' },
        { name: 'Pivot Calculator', href: '/pivot-calculator' },
        { name: 'Drawdown Calculator', href: '/drawdown-calculator' },
        { name: 'Risk of Ruin Calculator', href: '/risk-of-ruin-calculator' },
        { name: 'Crypto Fees Calculator', href: '/crypto-fees-calculator' },
      ]
    },
    { name: 'Live Charts', href: '/forex-charts' },
    { name: 'Market News', href: '/forex-news' },
    { name: 'Economic Calendar', href: '/economic-calendar' },
  ];

  return (
    <header className="bg-navy-900 shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-3">
            <div className="bg-gold-500 p-2 rounded-lg">
              <Calculator className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-lg sm:text-2xl font-bold text-gold-400">ForexCalculatorPro</h1>
          </Link>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            {navigation.map((item) => (
              <div key={item.name} className="relative">
                {item.subItems ? (
                  <div
                    className="relative"
                    onMouseEnter={() => setCalculatorsDropdownOpen(true)}
                    onMouseLeave={() => setCalculatorsDropdownOpen(false)}
                  >
                    <button className="text-white hover:text-gold-400 font-medium transition-colors duration-200 flex items-center">
                      {item.name}
                      <ChevronDown className="w-4 h-4 ml-1" />
                    </button>
                    
                    {calculatorsDropdownOpen && (
                      <div className="absolute top-full left-0 mt-2 w-64 bg-white rounded-lg shadow-lg border border-gray-200 py-2 z-50">
                        {item.subItems.map((subItem) => (
                          <Link
                            key={subItem.name}
                            href={subItem.href}
                            className="block px-4 py-2 text-navy-700 hover:bg-gray-50 hover:text-gold-600 transition-colors text-sm"
                          >
                            {subItem.name}
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                ) : (
                  <Link
                    href={item.href}
                    className="text-white hover:text-gold-400 font-medium transition-colors duration-200"
                  >
                    {item.name}
                  </Link>
                )}
              </div>
            ))}
          </nav>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden text-white hover:text-gold-400 hover:bg-navy-800"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <Menu className="w-6 h-6" />
            )}
          </Button>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-navy-700">
            <div className="flex flex-col space-y-2">
              {navigation.map((item) => (
                <div key={item.name}>
                  {item.subItems ? (
                    <div>
                      <button
                        className="flex items-center justify-between w-full text-white hover:text-gold-400 font-medium transition-colors duration-200 px-2 py-2"
                        onClick={() => setMobileCalculatorsOpen(!mobileCalculatorsOpen)}
                      >
                        {item.name}
                        <ChevronRight className={`w-4 h-4 transition-transform ${mobileCalculatorsOpen ? 'rotate-90' : ''}`} />
                      </button>
                      {mobileCalculatorsOpen && (
                        <div className="ml-4 mt-2 space-y-1">
                          {item.subItems.map((subItem) => (
                            <Link
                              key={subItem.name}
                              href={subItem.href}
                              className="block text-navy-200 hover:text-gold-400 text-sm py-1 px-2"
                              onClick={() => {
                                setIsMobileMenuOpen(false);
                                setMobileCalculatorsOpen(false);
                              }}
                            >
                              {subItem.name}
                            </Link>
                          ))}
                        </div>
                      )}
                    </div>
                  ) : (
                    <Link
                      href={item.href}
                      className="block text-white hover:text-gold-400 font-medium transition-colors duration-200 px-2 py-2"
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      {item.name}
                    </Link>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
      <LiveRatesTicker />
    </header>
  );
}
